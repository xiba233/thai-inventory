"""Persistent inventory application service. Snapshots are replacements, never deltas."""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .engine import DEFAULTS, calculate, validate_params, normalize_params
from .importer import parse_inventory, parse_transit
from .purchasing import PurchasingMixin

STATUSES = {"待补充信息", "待发货", "运输中", "清关中", "待入库", "已入库", "已取消"}
ACTIVE = STATUSES - {"已入库", "已取消"}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def dumps(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def iso_date(value, label="日期"):
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value)).isoformat()
    except (ValueError, TypeError):
        raise ValueError(f"{label}必须采用 YYYY-MM-DD 格式")


class Service(PurchasingMixin):
    def __init__(self, db_path):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            upgraded = "schema_migrations" in tables and conn.execute("SELECT 1 FROM schema_migrations WHERE version=5").fetchone()
            if tables and not upgraded:
                backup_dir = Path(self.db_path).parent / "backups"
                backup_dir.mkdir(exist_ok=True)
                backup_path = backup_dir / ("升级前_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f") + ".db")
                destination = sqlite3.connect(str(backup_path))
                try:
                    conn.backup(destination)
                finally:
                    destination.close()
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS imports (
                    id INTEGER PRIMARY KEY, filename TEXT NOT NULL, file_hash TEXT,
                    imported_at TEXT NOT NULL, snapshot_date TEXT, status TEXT NOT NULL,
                    report TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS import_hash ON imports(file_hash,snapshot_date,status);
                CREATE TABLE IF NOT EXISTS snapshot_rows (
                    import_id INTEGER NOT NULL REFERENCES imports(id), sku TEXT NOT NULL,
                    warehouse TEXT NOT NULL, data TEXT NOT NULL,
                    PRIMARY KEY(import_id,sku,warehouse));
                CREATE TABLE IF NOT EXISTS products (
                    sku TEXT NOT NULL, warehouse TEXT NOT NULL, data TEXT NOT NULL,
                    last_import INTEGER NOT NULL, updated_at TEXT NOT NULL,
                    PRIMARY KEY(sku,warehouse));
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS sku_settings (
                    sku TEXT NOT NULL, warehouse TEXT NOT NULL, clearance INTEGER,
                    params TEXT NOT NULL DEFAULT '{}', updated_at TEXT NOT NULL,
                    PRIMARY KEY(sku,warehouse));
                CREATE TABLE IF NOT EXISTS field_mappings (
                    signature TEXT PRIMARY KEY, mapping TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS clearance_mappings (
                    token TEXT PRIMARY KEY, candidates TEXT NOT NULL, kind TEXT NOT NULL,
                    confirmed INTEGER NOT NULL DEFAULT 0, skus TEXT NOT NULL DEFAULT '[]',
                    reviewed TEXT NOT NULL DEFAULT '[]', updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS transit (
                    id INTEGER PRIMARY KEY, sku TEXT NOT NULL, warehouse TEXT NOT NULL,
                    qty INTEGER NOT NULL CHECK(qty>=0), batch TEXT NOT NULL DEFAULT '',
                    eta TEXT, status TEXT NOT NULL, purchase_date TEXT, ship_date TEXT,
                    actual_date TEXT, note TEXT NOT NULL DEFAULT '', relation TEXT NOT NULL,
                    reconcile_state TEXT NOT NULL, linked_import INTEGER,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY, timestamp TEXT NOT NULL, action TEXT NOT NULL,
                    detail TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS transit_imports (
                    file_hash TEXT PRIMARY KEY, filename TEXT NOT NULL,
                    imported_at TEXT NOT NULL, report TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS retired_skus (
                    sku TEXT PRIMARY KEY, retired_at TEXT NOT NULL, note TEXT NOT NULL DEFAULT '');
                CREATE TABLE IF NOT EXISTS purchases (
                    id INTEGER PRIMARY KEY, sku TEXT NOT NULL, warehouse TEXT NOT NULL,
                    qty INTEGER NOT NULL CHECK(qty>0), completed_qty INTEGER NOT NULL CHECK(completed_qty>=0 AND completed_qty<=qty),
                    purchase_date TEXT NOT NULL, order_number TEXT NOT NULL DEFAULT '', supplier TEXT NOT NULL DEFAULT '',
                    eta TEXT, note TEXT NOT NULL DEFAULT '', cancelled INTEGER NOT NULL DEFAULT 0,
                    relation TEXT NOT NULL, reconcile_state TEXT NOT NULL, linked_import INTEGER,
                    request_key TEXT NOT NULL UNIQUE, request_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    FOREIGN KEY(sku,warehouse) REFERENCES products(sku,warehouse));
                CREATE TABLE IF NOT EXISTS purchase_shipments (
                    id INTEGER PRIMARY KEY, purchase_id INTEGER NOT NULL REFERENCES purchases(id),
                    transit_id INTEGER NOT NULL UNIQUE REFERENCES transit(id), qty INTEGER NOT NULL CHECK(qty>0),
                    ship_date TEXT NOT NULL, request_key TEXT NOT NULL UNIQUE, request_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL, voided_at TEXT);
                CREATE TABLE IF NOT EXISTS shipment_events (
                    id INTEGER PRIMARY KEY, sku TEXT NOT NULL, warehouse TEXT NOT NULL,
                    qty INTEGER NOT NULL CHECK(qty>0), ship_date TEXT NOT NULL,
                    request_key TEXT NOT NULL UNIQUE, request_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
            """)
            # Additive migration for databases created by earlier development builds.
            columns = {r[1] for r in conn.execute("PRAGMA table_info(clearance_mappings)")}
            if "reviewed" not in columns:
                conn.execute("ALTER TABLE clearance_mappings ADD COLUMN reviewed TEXT NOT NULL DEFAULT '[]'")
            if "archived_at" not in columns:
                conn.execute("ALTER TABLE clearance_mappings ADD COLUMN archived_at TEXT")
            transit_columns = {r[1] for r in conn.execute("PRAGMA table_info(transit)")}
            if "deleted_at" not in transit_columns:
                conn.execute("ALTER TABLE transit ADD COLUMN deleted_at TEXT")
            purchase_columns = {r[1] for r in conn.execute("PRAGMA table_info(purchases)")}
            if "deleted_at" not in purchase_columns:
                conn.execute("ALTER TABLE purchases ADD COLUMN deleted_at TEXT")
            if "reported_completed_qty" not in purchase_columns:
                conn.execute("ALTER TABLE purchases ADD COLUMN reported_completed_qty INTEGER NOT NULL DEFAULT 0")
                conn.execute("UPDATE purchases SET reported_completed_qty=completed_qty")
            shipment_columns = {r[1] for r in conn.execute("PRAGMA table_info(purchase_shipments)")}
            if "event_id" not in shipment_columns:
                conn.execute("ALTER TABLE purchase_shipments ADD COLUMN event_id INTEGER REFERENCES shipment_events(id)")
            # Migrate sparse SKU overrides without inventing new per-SKU defaults.
            saved = conn.execute("SELECT value FROM settings WHERE key='global'").fetchone()
            if saved:
                original = json.loads(saved["value"])
                migrated = normalize_params(original)
                if migrated != original:
                    conn.execute("UPDATE settings SET value=? WHERE key='global'", (dumps(migrated),))
            for saved in conn.execute("SELECT sku,warehouse,params FROM sku_settings").fetchall():
                original = json.loads(saved["params"])
                migrated = self._normalize_override(original)
                if migrated != original:
                    conn.execute("UPDATE sku_settings SET params=? WHERE sku=? AND warehouse=?", (dumps(migrated), saved["sku"], saved["warehouse"]))
            conn.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(2,?)", (now(),))
            conn.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(3,?)", (now(),))
            conn.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(4,?)", (now(),))
            conn.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(5,?)", (now(),))

    @staticmethod
    def _normalize_override(value):
        migrated = normalize_params(value)
        if "domestic_days" not in value:
            migrated.pop("domestic_days", None)
        return migrated

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.db_path, timeout=20)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=20000")
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _audit(self, conn, action, detail):
        conn.execute("INSERT INTO audit(timestamp,action,detail) VALUES(?,?,?)", (now(), action, dumps(detail)))

    def _latest(self, conn):
        return conn.execute("SELECT * FROM imports WHERE status='success' ORDER BY id DESC LIMIT 1").fetchone()

    def _settings(self, conn):
        result = dict(DEFAULTS)
        saved = conn.execute("SELECT value FROM settings WHERE key='global'").fetchone()
        if saved:
            result.update(normalize_params(json.loads(saved["value"])))
        return result

    def _parsed(self, content):
        parsed = parse_inventory(content)
        signature = parsed.get("signature")
        with self.connect() as conn:
            saved = conn.execute("SELECT mapping FROM field_mappings WHERE signature=?", (signature,)).fetchone()
        if saved:
            parsed = parse_inventory(content, saved_mapping=json.loads(saved["mapping"]))
        return parsed

    def preview(self, content, filename, snapshot_date=None):
        snapshot_date = iso_date(snapshot_date, "库存快照日期")
        parsed = self._parsed(content)
        parsed["filename"] = Path(str(filename)).name
        parsed["snapshot_date"] = snapshot_date
        if not snapshot_date:
            parsed.setdefault("warnings", []).append("库存快照日期未知；导入时间不能证明库存采集时间，风险结果请核实数据时效。")
        return parsed

    def preview_upload(self, content, filename, snapshot_date=None):
        """Log the user-facing upload separately from a committed stock snapshot."""
        snapshot_date = iso_date(snapshot_date, "库存快照日期")
        timestamp = now()
        try:
            parsed = self.preview(content, filename, snapshot_date)
        except Exception as exc:
            report = {"status": "preview_failed", "stage": "preview", "filename": Path(str(filename)).name,
                      "imported_at": timestamp, "snapshot_date": snapshot_date, "rows": 0,
                      "errors": [{"message": str(exc)}], "message": "预览解析失败，尚未更新库存。"}
            with self.connect() as conn:
                self._record_attempt(conn, content, report)
            raise ValueError(f"预览解析失败，已记录失败历史；现有库存未变更：{exc}") from exc
        report = {"status": "preview_failed" if parsed.get("errors") else "preview", "stage": "preview",
                  "filename": Path(str(filename)).name, "imported_at": timestamp,
                  "snapshot_date": snapshot_date, "rows": len(parsed.get("rows", [])),
                  "sku_count": len({r['sku'] for r in parsed.get('rows', [])}),
                  "errors": parsed.get("errors", []), "warnings": parsed.get("warnings", []),
                  "message": "文件预览已记录，尚未正式导入，当前库存未变更。"}
        with self.connect() as conn:
            history_id = self._record_attempt(conn, content, report)
        return {**parsed, "history_id": history_id, "preview_recorded_at": timestamp}

    def _record_attempt(self, conn, content, report):
        cursor = conn.execute("INSERT INTO imports(filename,file_hash,imported_at,snapshot_date,status,report) VALUES(?,?,?,?,?,?)",
                              (report["filename"], hashlib.sha256(content).hexdigest(), report["imported_at"],
                               report.get("snapshot_date"), report["status"], dumps(report)))
        report["id"] = cursor.lastrowid
        conn.execute("UPDATE imports SET report=? WHERE id=?", (dumps(report), report["id"]))
        self._audit(conn, "记录库存文件操作", report)
        return report["id"]

    def _failed_import(self, filename, content, snapshot_date, report):
        with self.connect() as conn:
            conn.execute("INSERT INTO imports(filename,file_hash,imported_at,snapshot_date,status,report) VALUES(?,?,?,?,?,?)",
                         (Path(str(filename)).name, hashlib.sha256(content).hexdigest(), now(), snapshot_date, "failed", dumps(report)))
            self._audit(conn, "库存导入失败", report)

    def import_inventory(self, content, filename, snapshot_date=None):
        snapshot_date = iso_date(snapshot_date, "库存快照日期")
        try:
            parsed = self.preview(content, filename, snapshot_date)
        except Exception as exc:
            report = {"filename": Path(str(filename)).name, "errors": [{"message": str(exc)}], "status": "failed"}
            self._failed_import(filename, content, snapshot_date, report)
            raise ValueError(f"Excel 解析失败，原有库存未变更：{exc}") from exc
        if parsed.get("errors") or not parsed.get("rows"):
            report = {"filename": Path(str(filename)).name, "errors": parsed.get("errors") or [{"message": "文件没有有效库存行"}],
                      "warnings": parsed.get("warnings", []), "status": "failed"}
            self._failed_import(filename, content, snapshot_date, report)
            messages = "；".join(str(e.get("message", e)) if isinstance(e, dict) else str(e) for e in report["errors"][:5])
            raise ValueError("导入验证失败，原有库存未变更：" + messages)
        file_hash = hashlib.sha256(content).hexdigest()
        timestamp = now()
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            duplicate = conn.execute("SELECT id,report FROM imports WHERE file_hash=? AND snapshot_date IS ? AND status='success' ORDER BY id DESC LIMIT 1",
                                     (file_hash, snapshot_date)).fetchone()
            if duplicate:
                result = json.loads(duplicate["report"])
                result.update({"status": "duplicate", "duplicate": True,
                               "source_import_id": duplicate["id"], "filename": Path(str(filename)).name,
                               "imported_at": timestamp, "snapshot_date": snapshot_date,
                               "message": "本次重复导入已记录；相同文件与快照日期已成功导入，不累计或改写当前库存。"})
                result.pop("id", None)
                self._record_attempt(conn, content, result)
                return result
            old = self._latest(conn)
            if old and snapshot_date and old["snapshot_date"] and snapshot_date < old["snapshot_date"]:
                message = f"新文件快照日期 {snapshot_date} 早于当前快照 {old['snapshot_date']}，不能用历史库存覆盖当前库存。"
                report = {"status": "failed", "errors": [{"message": message}], "warnings": parsed.get("warnings", [])}
                conn.execute("INSERT INTO imports(filename,file_hash,imported_at,snapshot_date,status,report) VALUES(?,?,?,?,?,?)",
                             (Path(str(filename)).name, file_hash, timestamp, snapshot_date, "failed", dumps(report)))
                self._audit(conn, "历史快照导入拒绝", report)
                conn.commit()
                raise ValueError(message)
            old_keys = {(r["sku"], r["warehouse"]) for r in conn.execute("SELECT sku,warehouse FROM products")}
            new_keys = {(r["sku"], r["warehouse"]) for r in parsed["rows"]}
            missing = sorted(old_keys - new_keys)
            report = {"status": "success", "duplicate": False, "filename": Path(str(filename)).name,
                      "rows": len(parsed["rows"]), "sku_count": len({r["sku"] for r in parsed["rows"]}),
                      "snapshot_date": snapshot_date, "imported_at": timestamp,
                      "errors": [], "warnings": parsed.get("warnings", []),
                      "missing": [{"sku": s, "warehouse": w} for s, w in missing],
                      "totals": {k: sum(r.get(k) or 0 for r in parsed["rows"]) for k in ("available", "locked", "transit", "sales7", "sales30")}}
            cursor = conn.execute("INSERT INTO imports(filename,file_hash,imported_at,snapshot_date,status,report) VALUES(?,?,?,?,?,?)",
                                  (report["filename"], file_hash, timestamp, snapshot_date, "success", dumps(report)))
            import_id = cursor.lastrowid
            report["id"] = import_id
            conn.execute("UPDATE imports SET report=? WHERE id=?", (dumps(report), import_id))
            for row in parsed["rows"]:
                row = dict(row)
                row["snapshot_date"] = snapshot_date
                row["imported_at"] = timestamp
                row["import_id"] = import_id
                serialized = dumps(row)
                conn.execute("INSERT INTO snapshot_rows(import_id,sku,warehouse,data) VALUES(?,?,?,?)", (import_id, row["sku"], row["warehouse"], serialized))
                conn.execute("INSERT INTO products(sku,warehouse,data,last_import,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(sku,warehouse) DO UPDATE SET data=excluded.data,last_import=excluded.last_import,updated_at=excluded.updated_at",
                             (row["sku"], row["warehouse"], serialized, import_id, timestamp))
            conn.execute("INSERT INTO field_mappings(signature,mapping,updated_at) VALUES(?,?,?) ON CONFLICT(signature) DO UPDATE SET mapping=excluded.mapping,updated_at=excluded.updated_at",
                         (parsed["signature"], dumps(parsed["mapping"]), timestamp))
            # Preserve user confirmations; a newly introduced candidate is never auto-confirmed.
            for entry in parsed.get("clearance", []):
                existing = conn.execute("SELECT confirmed,skus,reviewed FROM clearance_mappings WHERE token=?", (entry["token"],)).fetchone()
                confirmed = existing["confirmed"] if existing else int(entry["kind"] == "exact")
                chosen = json.loads(existing["skus"]) if existing else (entry["candidates"] if confirmed else [])
                reviewed = json.loads(existing["reviewed"]) if existing else (entry["candidates"] if confirmed else [])
                conn.execute("INSERT INTO clearance_mappings(token,candidates,kind,confirmed,skus,reviewed,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(token) DO UPDATE SET candidates=excluded.candidates,kind=excluded.kind,updated_at=excluded.updated_at",
                             (entry["token"], dumps(entry["candidates"]), entry["kind"], confirmed, dumps(chosen), dumps(reviewed), timestamp))
            # A standard file without a clearance sheet still refreshes persisted rules.
            current_skus = {r["sku"] for r in parsed["rows"]}
            for saved in conn.execute("SELECT token FROM clearance_mappings").fetchall():
                token = saved["token"]
                exact = token in current_skus
                candidates = [token] if exact else sorted(s for s in current_skus if s.startswith(token + "-"))
                kind = "exact" if exact else ("boundary" if candidates else "unmatched")
                conn.execute("UPDATE clearance_mappings SET candidates=?,kind=?,updated_at=? WHERE token=?", (dumps(candidates), kind, timestamp, token))
            # A snapshot does not identify batches. Do not silently retain previous allocation.
            if old:
                conn.execute("UPDATE transit SET reconcile_state='pending',updated_at=? WHERE status NOT IN ('已入库','已取消') AND relation!='exclude' AND deleted_at IS NULL", (timestamp,))
            if old:
                conn.execute("UPDATE purchases SET reconcile_state='pending',updated_at=? WHERE deleted_at IS NULL AND cancelled=0 AND relation!='exclude' AND qty>(SELECT COALESCE(sum(qty),0) FROM purchase_shipments WHERE purchase_id=purchases.id AND voided_at IS NULL)", (timestamp,))
            self._audit(conn, "库存快照导入", report)
            return report

    def save_settings(self, value):
        if not isinstance(value, dict):
            raise ValueError("设置必须是参数对象")
        value = normalize_params(value)
        with self.connect() as conn:
            params = self._settings(conn)
            unknown = set(value) - set(DEFAULTS)
            if unknown:
                raise ValueError("未知设置：" + "、".join(sorted(unknown)))
            params.update(value)
            validate_params(params)
            conn.execute("INSERT INTO settings(key,value) VALUES('global',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (dumps(params),))
            self._audit(conn, "保存全局参数", params)
        return {"ok": True}

    def _key(self, conn, value):
        sku, warehouse = str(value.get("sku", "")).strip(), str(value.get("warehouse", "")).strip()
        if not conn.execute("SELECT 1 FROM products WHERE sku=? AND warehouse=?", (sku, warehouse)).fetchone():
            raise ValueError("SKU 与仓库不存在，请先导入库存或检查编码")
        return sku, warehouse

    def save_sku(self, value):
        with self.connect() as conn:
            sku, warehouse = self._key(conn, value)
            previous = conn.execute("SELECT * FROM sku_settings WHERE sku=? AND warehouse=?", (sku, warehouse)).fetchone()
            params = value.get("params", json.loads(previous["params"]) if previous else {})
            params = self._normalize_override(params)
            if not isinstance(params, dict) or set(params) - set(DEFAULTS):
                raise ValueError("SKU 参数包含未知字段")
            merged = self._settings(conn)
            merged.update(params)
            validate_params(merged)
            clearance = value.get("clearance", previous["clearance"] if previous else None)
            if clearance not in (True, False, None, 0, 1):
                raise ValueError("清仓状态应为是、否或恢复自动")
            clearance = None if clearance is None else int(bool(clearance))
            conn.execute("INSERT INTO sku_settings(sku,warehouse,clearance,params,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(sku,warehouse) DO UPDATE SET clearance=excluded.clearance,params=excluded.params,updated_at=excluded.updated_at",
                         (sku, warehouse, clearance, dumps(params), now()))
            self._audit(conn, "保存 SKU 设置", {"sku": sku, "warehouse": warehouse, "clearance": clearance, "params": params})
        return {"ok": True}

    def save_factory_batch(self, value):
        """Compatibility for the original production-only batch endpoint."""
        if not isinstance(value, dict) or set(value) != {"items", "factory_days"}:
            raise ValueError("批量设置需要商品列表与工厂生产天数")
        result = self.save_lead_batch({"items": value["items"], "params": {"factory_days": value["factory_days"]}})
        return {**result, "factory_days": value["factory_days"]}

    def save_lead_batch(self, value):
        """Sparse cycle patch: omitted fields stay unchanged, null inherits global."""
        if not isinstance(value, dict) or set(value) != {"items", "params"}:
            raise ValueError("批量设置需要商品列表与要修改的周期")
        items, patch = value["items"], value["params"]
        if not isinstance(items, list) or not 1 <= len(items) <= 5000:
            raise ValueError("请勾选1至5000条 SKU / 仓库记录")
        allowed = {"factory_days", "domestic_days", "crossborder_days"}
        if not isinstance(patch, dict) or not patch or set(patch) - allowed:
            raise ValueError("请至少选择一种生产或物流周期，只支持工厂、国内和泰国跨境天数")
        for field, days in patch.items():
            if days is not None:
                validate_params({field: days})
        patch = {field: None if days is None else int(days) for field, days in patch.items()}
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            changes, seen = [], set()
            for item in items:
                if not isinstance(item, dict) or set(item) != {"sku", "warehouse"} or not all(isinstance(v, str) and v.strip() for v in item.values()):
                    raise ValueError("每条商品必须包含完整 SKU 和仓库文本")
                sku, warehouse = self._key(conn, item)
                if (sku, warehouse) in seen:
                    raise ValueError("批量列表有重复 SKU / 仓库，本次未保存")
                seen.add((sku, warehouse))
                if conn.execute("SELECT 1 FROM retired_skus WHERE sku=?", (sku,)).fetchone():
                    raise ValueError("已清仓完成商品不能批量设置，请先恢复商品")
                previous = conn.execute("SELECT * FROM sku_settings WHERE sku=? AND warehouse=?", (sku, warehouse)).fetchone()
                params = self._normalize_override(json.loads(previous["params"]) if previous else {})
                old_values = {field: params.get(field) for field in patch}
                for field, days in patch.items():
                    if days is None:
                        params.pop(field, None)
                    else:
                        params[field] = days
                merged = self._settings(conn)
                merged.update(params)
                validate_params(merged)
                changes.append((sku, warehouse, previous["clearance"] if previous else None, params, old_values))
            timestamp = now()
            for sku, warehouse, clearance, params, _ in changes:
                conn.execute("INSERT INTO sku_settings(sku,warehouse,clearance,params,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(sku,warehouse) DO UPDATE SET params=excluded.params,updated_at=excluded.updated_at",
                             (sku, warehouse, clearance, dumps(params), timestamp))
            self._audit(conn, "批量设置工厂生产天数" if set(patch) == {"factory_days"} else "批量设置生产与物流周期",
                        {"count": len(changes), "params": patch,
                         "items": [{"sku": s, "warehouse": w, "previous_overrides": old} for s, w, _, _, old in changes]})
        return {"ok": True, "count": len(changes), "params": patch}

    def save_mapping(self, value):
        token, skus = str(value.get("token", "")).strip(), value.get("skus", [])
        if not isinstance(skus, list) or not all(isinstance(s, str) for s in skus):
            raise ValueError("确认商品列表必须是 SKU 文本数组")
        with self.connect() as conn:
            mapping = conn.execute("SELECT candidates,archived_at FROM clearance_mappings WHERE token=?", (token,)).fetchone()
            if not mapping:
                raise ValueError("该清仓标识不存在")
            if mapping["archived_at"]:
                raise ValueError("该清仓映射已归档，请先恢复映射后再确认")
            known = {r[0] for r in conn.execute("SELECT DISTINCT sku FROM products")}
            if set(skus) - known:
                raise ValueError("确认列表包含不存在的 SKU")
            reviewed = sorted(set(json.loads(mapping["candidates"])) | set(skus))
            conn.execute("UPDATE clearance_mappings SET skus=?,confirmed=?,reviewed=?,updated_at=? WHERE token=?",
                         (dumps(sorted(set(skus))), int(value.get("confirmed", True)), dumps(reviewed), now(), token))
            self._audit(conn, "确认清仓映射", value)
        return {"ok": True}

    def retire(self, value):
        skus = value.get("skus", [])
        token = value.get("token")
        note = value.get("note", "")
        if not isinstance(skus, list) or any(not isinstance(s, str) or not s for s in skus):
            raise ValueError("完成清仓必须选择精确 SKU 文本列表")
        if not isinstance(note, str) or (token is not None and (not isinstance(token, str) or not token)):
            raise ValueError("清仓备注或映射标识无效")
        if not skus and not token:
            raise ValueError("请至少选择一个 SKU 或需要归档的清仓标识")
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            known = {r[0] for r in conn.execute("SELECT DISTINCT sku FROM products")}
            if set(skus) - known:
                raise ValueError("完成列表包含不存在的 SKU，本次未变更任何商品")
            if token and not conn.execute("SELECT 1 FROM clearance_mappings WHERE token=?", (token,)).fetchone():
                raise ValueError("该清仓映射不存在")
            timestamp = now()
            for sku in sorted(set(skus)):
                conn.execute("INSERT INTO retired_skus(sku,retired_at,note) VALUES(?,?,?) ON CONFLICT(sku) DO UPDATE SET note=excluded.note", (sku, timestamp, note))
            if token:
                conn.execute("UPDATE clearance_mappings SET archived_at=COALESCE(archived_at,?),updated_at=? WHERE token=?", (timestamp, timestamp, token))
            self._audit(conn, "清仓完成并排除全部仓库商品", {"skus": sorted(set(skus)), "token": token, "note": note})
        return {"ok": True, "skus": sorted(set(skus)), "token": token}

    def restore_sku(self, value):
        sku = value.get("sku")
        if not isinstance(sku, str) or not sku:
            raise ValueError("恢复时必须提供精确 SKU")
        with self.connect() as conn:
            if not conn.execute("SELECT 1 FROM retired_skus WHERE sku=?", (sku,)).fetchone():
                raise ValueError("该 SKU 没有完成清仓记录")
            conn.execute("DELETE FROM retired_skus WHERE sku=?", (sku,))
            self._audit(conn, "恢复清仓完成商品", {"sku": sku})
        return {"ok": True}

    def restore_clearance(self, value):
        token = value.get("token")
        if not isinstance(token, str) or not token:
            raise ValueError("恢复时必须提供清仓映射标识")
        with self.connect() as conn:
            if not conn.execute("SELECT 1 FROM clearance_mappings WHERE token=? AND archived_at IS NOT NULL", (token,)).fetchone():
                raise ValueError("该清仓映射未归档或不存在")
            conn.execute("UPDATE clearance_mappings SET archived_at=NULL,updated_at=? WHERE token=?", (now(), token))
            self._audit(conn, "恢复归档清仓映射", {"token": token})
        return {"ok": True}

    @staticmethod
    def _record_id(value):
        if isinstance(value, bool) or not isinstance(value, int) or not 0 < value <= 9223372036854775807:
            raise ValueError("记录 ID 必须是正整数")
        return value

    def remove_transit(self, value):
        """UI removal: linked shipments are reversed atomically, never orphaned."""
        item_id = self._record_id(value.get('id'))
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            saved = conn.execute('SELECT * FROM transit WHERE id=?', (item_id,)).fetchone()
            if not saved:
                raise ValueError('该采购 / 物流明细不存在')
            link = conn.execute('SELECT id FROM purchase_shipments WHERE transit_id=?', (item_id,)).fetchone()
            if link:
                result = self._undo_purchase_shipment(conn, {'id': link['id'], 'retry_safe': True})
                return dict(result, id=item_id, mode='shipment_undone')
            if saved['deleted_at']:
                return {'ok': True, 'id': item_id, 'duplicate': True, 'mode': 'independent_deleted'}
            timestamp = now()
            conn.execute('UPDATE transit SET deleted_at=?,updated_at=? WHERE id=?', (timestamp, timestamp, item_id))
            self._audit(conn, '删除采购与物流明细', {'id': item_id, 'previous': dict(saved), 'snapshot_unchanged': True})
        return {'ok': True, 'id': item_id, 'mode': 'independent_deleted'}

    def delete_transit(self, value):
        item_id = self._record_id(value.get("id"))
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            saved = conn.execute("SELECT * FROM transit WHERE id=? AND deleted_at IS NULL", (item_id,)).fetchone()
            if not saved:
                raise ValueError("该在途记录不存在或已删除")
            if conn.execute("SELECT 1 FROM purchase_shipments WHERE transit_id=? AND voided_at IS NULL", (item_id,)).fetchone():
                raise ValueError("该在途由采购分批出货生成，请在已采购未出货页面撤销误录出货；不能直接删除破坏数量流转")
            timestamp = now()
            conn.execute("UPDATE transit SET deleted_at=?,updated_at=? WHERE id=?", (timestamp, timestamp, item_id))
            self._audit(conn, "软删除指定在途明细", {"id": item_id, "previous": dict(saved), "snapshot_unchanged": True})
        return {"ok": True, "id": item_id}

    def _transit_value(self, conn, value, allow_blank_duplicates=False):
        sku, warehouse = self._key(conn, value)
        qty = value.get("qty")
        try:
            number = float(qty)
            if isinstance(qty, bool) or not math.isfinite(number) or not 0 < number <= 10 ** 12 or not number.is_integer():
                raise ValueError()
            qty = int(number)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("在途明细数量必须为 1 至 1,000,000,000,000 的整数")
        status, relation = value.get("status", "待发货"), value.get("relation", "snapshot")
        if status not in STATUSES:
            raise ValueError("在途状态无效")
        if relation not in {"snapshot", "new", "exclude"}:
            raise ValueError("在途归属只能为 snapshot、new 或 exclude")
        result = {"sku": sku, "warehouse": warehouse, "qty": qty,
                  "batch": str(value.get("batch") or "").strip(), "status": status,
                  "relation": relation, "note": str(value.get("note") or "").strip()}
        for field in ("eta", "purchase_date", "ship_date", "actual_date"):
            result[field] = iso_date(value.get(field), field)
        if status == "已入库" and not result["actual_date"]:
            raise ValueError("已入库记录必须填写实际入库日期；库存由下一次 Excel 快照确认")
        if result["purchase_date"] and result["ship_date"] and result["purchase_date"] > result["ship_date"]:
            raise ValueError("发货日期不能早于采购日期")
        if result["ship_date"] and result["actual_date"] and result["ship_date"] > result["actual_date"]:
            raise ValueError("实际入库日期不能早于发货日期")
        item_id = value.get("id")
        if item_id is not None:
            item_id = self._record_id(item_id)
        if result["batch"] and status in ACTIVE:
            duplicate = conn.execute("SELECT id FROM transit WHERE sku=? AND warehouse=? AND batch=? AND status NOT IN ('已入库','已取消') AND deleted_at IS NULL AND id!=?",
                                     (sku, warehouse, result["batch"], item_id or -1)).fetchone()
            if duplicate:
                raise ValueError(f"该 SKU 与仓库已有相同批次记录（ID {duplicate['id']}），请编辑原记录")
        elif status in ACTIVE and not allow_blank_duplicates:
            duplicate = conn.execute("SELECT id FROM transit WHERE sku=? AND warehouse=? AND batch='' AND qty=? AND eta IS ? AND purchase_date IS ? AND ship_date IS ? AND relation=? AND status NOT IN ('已入库','已取消') AND deleted_at IS NULL AND id!=?",
                                     (sku, warehouse, qty, result['eta'], result['purchase_date'], result['ship_date'], relation, item_id or -1)).fetchone()
            if duplicate:
                raise ValueError(f"缺少批次号且与已有明细（ID {duplicate['id']}）相同，无法确认是否同批货物；请编辑原记录或补充真实批次号")
        return result

    def _write_transit(self, conn, value, purchase_transfer=False):
        link = conn.execute("SELECT * FROM purchase_shipments WHERE transit_id=? AND voided_at IS NULL", (value.get("id"),)).fetchone() if value.get("id") is not None else None
        item = self._transit_value(conn, value, allow_blank_duplicates=purchase_transfer or bool(link))
        if link:
            old = conn.execute("SELECT * FROM transit WHERE id=?", (value["id"],)).fetchone()
            for key in ("sku", "warehouse", "qty", "purchase_date", "ship_date"):
                if item[key] != old[key]:
                    raise ValueError("采购关联出货的SKU、仓库、数量与实际出货/采购日期不可在在途页面改写；误录请从采购出货历史撤销")
            if item["status"] in {"待发货", "待补充信息"}:
                raise ValueError("已记录实际出货的批次不能改回未出货；请从采购页面处理误录")
            if item["eta"] and item["eta"] < item["ship_date"]:
                raise ValueError("本批预计入库日期不能早于实际出货日期")
            if item["actual_date"] and item["actual_date"] > datetime.now(timezone(timedelta(hours=7))).date().isoformat():
                raise ValueError("实际入库日期不能填写未来时间")
        latest = self._latest(conn)
        item.update({"linked_import": latest["id"] if latest else None, "reconcile_state": "confirmed", "updated_at": now()})
        fields = list(item)
        item_id = value.get("id")
        if item_id is not None:
            item_id = self._record_id(item_id)
            if not conn.execute("SELECT 1 FROM transit WHERE id=? AND deleted_at IS NULL", (item_id,)).fetchone():
                raise ValueError("在途记录不存在或已删除")
            conn.execute("UPDATE transit SET " + ",".join(f"{f}=?" for f in fields) + " WHERE id=?", [item[f] for f in fields] + [item_id])
        else:
            item["created_at"] = now()
            fields = list(item)
            cursor = conn.execute("INSERT INTO transit(" + ",".join(fields) + ") VALUES(" + ",".join("?" for _ in fields) + ")", [item[f] for f in fields])
            item_id = cursor.lastrowid
        if not purchase_transfer and item["relation"] == "snapshot" and conn.execute("SELECT 1 FROM purchases WHERE sku=? AND warehouse=?", (item["sku"], item["warehouse"])).fetchone():
            self._validate_purchase_allocation(conn, item["sku"], item["warehouse"])
        self._audit(conn, "保存在途明细", {"id": item_id, **item})
        return item_id

    def save_transit(self, value):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            item_id = self._write_transit(conn, value)
        return {"ok": True, "id": item_id}

    def reconcile(self, value):
        relation = value.get("relation")
        if relation not in {"snapshot", "new", "exclude"}:
            raise ValueError("请明确该批货物已包含快照、属于快照外新增或应排除")
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            item_id = self._record_id(value.get("id"))
            item = conn.execute("SELECT * FROM transit WHERE id=? AND deleted_at IS NULL", (item_id,)).fetchone()
            if not item:
                raise ValueError("在途记录不存在")
            latest = self._latest(conn)
            conn.execute("UPDATE transit SET relation=?,reconcile_state='confirmed',linked_import=?,updated_at=? WHERE id=?",
                         (relation, latest["id"] if latest else None, now(), item["id"]))
            if relation == "snapshot" and conn.execute("SELECT 1 FROM purchases WHERE sku=? AND warehouse=?", (item["sku"], item["warehouse"])).fetchone():
                self._validate_purchase_allocation(conn, item["sku"], item["warehouse"])
            self._audit(conn, "在途快照核对", value)
        return {"ok": True}

    def import_transit(self, content, filename):
        parsed = parse_transit(content)
        if parsed.get("errors"):
            return {"status": "failed", **parsed}
        try:
            with self.connect() as conn:
                conn.execute("BEGIN IMMEDIATE")
                # Workbook metadata can change while rows remain identical.
                normalized_rows = sorted(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) for row in parsed.get("rows", []))
                if len(normalized_rows) != len(set(normalized_rows)):
                    raise ValueError("在途文件包含完全相同的重复明细，无法区分同批货物，请移除重复行或提供真实批次号")
                canonical = dumps(normalized_rows)
                file_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                previous = conn.execute("SELECT report FROM transit_imports WHERE file_hash=?", (file_hash,)).fetchone()
                if previous:
                    return {**json.loads(previous["report"]), "duplicate": True, "message": "相同在途文件已导入，本次未重复新增。"}
                identifiers = [self._write_transit(conn, r) for r in parsed.get("rows", [])]
                report = {"status": "success", "rows": len(identifiers), "ids": identifiers, "warnings": parsed.get("warnings", []), "duplicate": False}
                conn.execute("INSERT INTO transit_imports(file_hash,filename,imported_at,report) VALUES(?,?,?,?)",
                             (file_hash, Path(str(filename)).name, now(), dumps(report)))
                self._audit(conn, "在途明细批量导入", {"filename": Path(str(filename)).name, "ids": identifiers})
        except ValueError as exc:
            return {"status": "failed", "errors": [{"message": str(exc)}], "warnings": parsed.get("warnings", [])}
        return report

    def state(self):
        with self.connect() as conn:
            settings = self._settings(conn)
            latest = self._latest(conn)
            current_id = latest["id"] if latest else None
            products = conn.execute("SELECT * FROM products ORDER BY sku,warehouse").fetchall()
            retired_skus = {r["sku"]: dict(r) for r in conn.execute("SELECT * FROM retired_skus")}
            overrides = {(r["sku"], r["warehouse"]): dict(r) for r in conn.execute("SELECT * FROM sku_settings")}
            transits = [dict(r) for r in conn.execute("SELECT * FROM transit WHERE deleted_at IS NULL ORDER BY id DESC")]
            purchases, purchase_shipments = self.purchase_state(conn, products, transits, current_id, retired_skus)
            deleted_purchases = [p for p in purchases if p["deleted_at"]]
            purchases = [p for p in purchases if not p["deleted_at"]]
            shipment_events = []
            for event in conn.execute('SELECT * FROM shipment_events ORDER BY id DESC'):
                item = dict(event)
                item['allocations'] = sorted([s for s in purchase_shipments if s.get('event_id') == item['id']], key=lambda s: (s['purchase_date'], s['purchase_id'], s['id']))
                item['active_qty'] = sum(s['qty'] for s in item['allocations'] if not s['voided_at'])
                item['voided_qty'] = item['qty'] - item['active_qty']
                item['name'] = item['allocations'][0]['name'] if item['allocations'] else ''
                shipment_events.append(item)
            entries = []
            auto_clearance, pending_clearance = set(), set()
            for saved in conn.execute("SELECT * FROM clearance_mappings ORDER BY token"):
                entry = dict(saved)
                entry["candidates"], entry["skus"] = json.loads(entry["candidates"]), json.loads(entry["skus"])
                entry["reviewed"] = json.loads(entry["reviewed"])
                entry["confirmed"] = bool(entry["confirmed"])
                entries.append(entry)
                if entry.get("archived_at"):
                    continue
                if entry["confirmed"]:
                    auto_clearance.update(entry["skus"])
                    pending_clearance.update(set(entry["candidates"]) - set(entry["reviewed"]))
                else:
                    pending_clearance.update(entry["candidates"])
            imports = []
            for record in conn.execute("SELECT id,filename,imported_at,snapshot_date,status,report FROM imports ORDER BY id DESC"):
                item = dict(record)
                item["report"] = json.loads(item["report"])
                imports.append(item)
        rows, warnings, transit_summary, retired = [], [], [], []
        for record in products:
            row = json.loads(record["data"])
            row["missing"] = record["last_import"] != current_id
            if row["sku"] in retired_skus:
                retired.append({**row, **retired_skus[row["sku"]]})
                continue
            key = row["sku"], row["warehouse"]
            override = overrides.get(key, {})
            params = dict(settings)
            own_params = self._normalize_override(json.loads(override.get("params", "{}")))
            params.update(own_params)
            clearance = row["sku"] in auto_clearance
            if override.get("clearance") is not None:
                clearance = bool(override["clearance"])
            pending = row["sku"] in pending_clearance and not clearance and override.get("clearance") is None
            active = [t for t in transits if (t["sku"], t["warehouse"]) == key and t["status"] in ACTIVE and t["relation"] != "exclude"]
            confirmed = [t for t in active if t["reconcile_state"] == "confirmed" and t["linked_import"] == current_id]
            matched = [t for t in confirmed if t["relation"] == "snapshot"]
            additions = [t for t in confirmed if t["relation"] == "new"]
            snapshot_qty = row.get("transit") or 0
            matched_qty = sum(t["qty"] for t in matched)
            order_rows = [p for p in purchases if (p["sku"], p["warehouse"]) == key and not p["cancelled"] and p["unshipped_qty"] > 0 and p["relation"] != "exclude"]
            confirmed_orders = [p for p in order_rows if p["reconcile_state"] == "confirmed" and p["linked_import"] == current_id]
            planned_matched = sum(p["unshipped_qty"] for p in confirmed_orders if p["relation"] == "snapshot")
            conflict = matched_qty + planned_matched > snapshot_qty
            if conflict:
                warnings.append(f"{row['sku']} / {row['warehouse']}：已匹配出货 {matched_qty} +未出货采购 {planned_matched} 超过快照在途 {snapshot_qty}，在途差异待核实，暂停其快照明细到货抵扣。")
            arrivals = [dict(t) for t in additions]
            if not conflict:
                arrivals.extend(dict(t) for t in matched)
                if snapshot_qty > matched_qty + planned_matched:
                    arrivals.append({"qty": snapshot_qty - matched_qty - planned_matched, "eta": None, "status": "运输中"})
            elif snapshot_qty > planned_matched:
                arrivals.append({"qty": snapshot_qty - planned_matched, "eta": None, "status": "运输中"})
            total = max(0, snapshot_qty - planned_matched) + sum(t["qty"] for t in additions)
            row["procurement_unshipped"] = sum(p["unshipped_qty"] for p in confirmed_orders)
            row["procurement_pending"] = sum(p["unshipped_qty"] for p in order_rows if p not in confirmed_orders) + sum(t["qty"] for t in active if t.get("purchase_id") and t not in confirmed)
            row["procurement_reserve"] = row["procurement_unshipped"] + sum(t["qty"] for t in confirmed if t.get("purchase_id") and (t["relation"] == "new" or not conflict))
            row["procurement_blocked"] = bool(row["procurement_pending"] or (conflict and (order_rows or any(t.get("purchase_id") for t in active))))
            purchase_arrivals = [{"qty": p["unshipped_qty"], "eta": p["eta"], "status": "待发货"} for p in confirmed_orders] if not conflict else []
            row["future_supply_total"] = None if row.get("available") is None or conflict else row["available"] + total + row["procurement_unshipped"]
            row["transit_total"] = total
            row["clearance"] = clearance
            row["pending_clearance"] = pending
            row["clearance_override"] = override.get("clearance")
            row["params"] = params
            row["sku_params"] = own_params
            row["transit_conflict"] = conflict
            row["transit_pending"] = sum(t["qty"] for t in active if t not in confirmed)
            row["snapshot_transit"] = snapshot_qty
            row["matched_transit"] = matched_qty
            row["new_transit"] = sum(t["qty"] for t in additions)
            if snapshot_qty or active:
                transit_summary.append({"sku": row["sku"], "warehouse": row["warehouse"], "name": row.get("name", ""),
                                        "qty": snapshot_qty, "matched_qty": matched_qty, "planned_matched_qty": planned_matched, "new_qty": row["new_transit"],
                                        "pending_qty": row["transit_pending"], "total_qty": total,
                                        "eta": None, "batch": "", "status": "待补充信息" if snapshot_qty > matched_qty else "已补充明细",
                                        "conflict": conflict, "missing": row["missing"]})
            computed = calculate(row, params=params, arrivals=arrivals, clearance=clearance, purchase_arrivals=purchase_arrivals)
            if row["procurement_blocked"] and not clearance and computed["suggestion"] is not None:
                computed["suggestion"] = None
                computed["reason"] += "；采购或出货与快照归属待核对，暂停新增采购建议"
            if pending:
                computed["suggestion"] = None
                computed["reason"] = str(computed.get("reason", "")) + "；清仓型号映射待确认，暂缓普通采购建议。"
                computed["explanation"] = str(computed.get("explanation", "")) + "；请确认清仓映射，或在 SKU 设置中明确标记非清仓后再采购。"
            if row["missing"]:
                computed["suggestion"] = None
                computed["reason"] = "最新快照未包含此 SKU，保留最后一次记录待核实；不计入当前统计。"
            rows.append(computed)
        present = [r for r in rows if not r.get("missing")]
        kpis = {k: sum(r.get(k) or 0 for r in present) for k in ("available", "locked", "sales7", "sales30")}
        kpis.update({"transit": sum(r.get("transit_total") or 0 for r in present),
                     "procurement_unshipped": sum(r.get("procurement_unshipped") or 0 for r in present),
                     "procurement_pending": sum(r.get("procurement_pending") or 0 for r in present),
                     "high_risk": sum(r.get("risk") in {"P0", "P1"} for r in present),
                     "oos": sum(r.get("available") == 0 and any((r.get(k) or 0) > 0 for k in ("sales7", "sales15", "sales30")) for r in present),
                     "suggestion": sum(r.get("suggestion") or 0 for r in present),
                     "sku_count": len({r["sku"] for r in present}), "missing": len(rows) - len(present),
                     "suggestion_pending": sum(r.get("suggestion") is None for r in present)})
        for sales_field, label in (("sales7", "近 7 天"), ("sales30", "近 30 天")):
            count = sum(r.get(sales_field) is None for r in present)
            kpis[sales_field + "_missing"] = count
            if count:
                warnings.append(f"{label}销量有 {count} 条缺失，当前销量合计仅包含已知值；缺失不等同于零销量。")
        snapshot = {k: latest[k] for k in ("id", "filename", "imported_at", "snapshot_date")} if latest else None
        if latest and not latest["snapshot_date"]:
            warnings.append("库存快照日期未知；数据时效无法确认。导入时间与商品创建日期均不能代替库存快照日期。")
        elif latest and latest["snapshot_date"] and (datetime.now(timezone(timedelta(hours=7))).date() - date.fromisoformat(latest["snapshot_date"])).days > settings.get("stale_days", 7):
            warnings.append(f"当前库存快照日期 {latest['snapshot_date']} 已超过时效阈值，请导入最新数据后执行采购。")
        elif latest and latest["snapshot_date"] and date.fromisoformat(latest["snapshot_date"]) > datetime.now(timezone(timedelta(hours=7))).date():
            warnings.append("当前快照日期在未来，请核实日期来源；计算结果仅供待核实分析。")
        if settings.get("assumed"):
            warnings.append("采购及运输周期采用暂定假设，请在设置中根据真实供应链修改并取消假设标记。")
        if any(t["reconcile_state"] == "pending" and t["status"] in ACTIVE for t in transits):
            warnings.append("存在待核对在途批次：最新库存快照未提供批次对应关系，明细暂不追加或抵扣，请逐批确认归属。")
        if any(r.get("procurement_blocked") for r in present):
            warnings.append("存在待核对采购/关联出货数量，相关SKU暂停新增采购建议；请核对与最新Excel快照的关系，避免重复采购或重复统计。")
        return {"shipment_events": shipment_events, "deleted_purchases": deleted_purchases, "purchases": purchases, "purchase_shipments": purchase_shipments, "rows": rows, "settings": settings, "imports": imports, "clearance": entries,
                "transit": transits, "transit_summary": transit_summary, "retired": retired, "snapshot": snapshot, "kpis": kpis, "warnings": warnings}

