"""Untrusted XLSX inputs are data only: no macros, formulas or external evaluation."""
from __future__ import annotations

from collections import Counter
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import re
from zipfile import ZipFile, BadZipFile

from openpyxl import load_workbook
from openpyxl.cell.read_only import EmptyCell

STANDARD = json.loads(Path(__file__).with_name('standard.json').read_text(encoding='utf-8'))


FIELDS = {
    'sku': ['SKU', '商品编码', 'SKU（商品编码）'],
    'warehouse': ['Warehouse Name', '仓库名称', '仓库'],
    'name': ['Goods Name', '商品名称'],
    'total': ['Total Quantity', '总数量'],
    'available': ['Effective Stock', '有效库存', '可售库存'],
    'locked': ['Lock Stock', '锁定库存'],
    'transit': ['Transit Stock', '在途库存'],
    'warning': ['Warning Quantity', '预警库存'],
    'turnover': ['Turnover Days', '周转天数'],
    'sales7': ['7 Days Sales', '7天销量', '7 天销量'],
    'sales15': ['15 Days Sales', '15天销量', '15 天销量'],
    'sales30': ['30 Days Sales', '30天销量', '30 天销量'],
    'image': ['Image URL', '图片链接', '图片URL'],
    'category': ['Category', '商品分类'],
    'created': ['Create Time', '创建时间', '商品创建时间'],
}
TRANSIT_FIELDS = {
    'sku': ['SKU', '商品编码'], 'warehouse': ['Warehouse Name', '仓库', '仓库名称'],
    'qty': ['qty', 'Quantity', '数量', '在途数量'],
    'batch': ['batch', 'Batch Number', '批次编号', '采购单号', '采购单号或物流批次编号'],
    'eta': ['eta', '预计到货日期'], 'status': ['status', '在途状态', '状态'],
    'purchase_date': ['purchase_date', '采购日期'], 'ship_date': ['ship_date', '发货日期'],
    'actual_date': ['actual_date', '实际入库日期'], 'note': ['note', '物流备注', '备注'],
    'relation': ['relation', '关联方式', '来源关系', '快照关系'],
}
ACTIVE_STATUSES = {'待发货', '运输中', '清关中', '待入库', '待补充信息'}
ALL_STATUSES = ACTIVE_STATUSES | {'已入库', '已取消'}


def normalize(value):
    """Bilingual headers use the first line; punctuation/spacing do not matter."""
    text = str(value or '').split('\n')[0].replace('*', '').strip()
    return re.sub(r'[\s_()（）]+', '', text).casefold()


def _json(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def _error(errors, sheet, row, field, value, message):
    errors.append({'sheet': sheet, 'row': row, 'field': field, 'value': _json(value), 'message': message})


def _open(content):
    if not isinstance(content, bytes) or not content:
        raise ValueError('请选择非空 XLSX 文件')
    if len(content) > 15 * 1024 * 1024:
        raise ValueError('XLSX 文件超过 15 MB 上限')
    try:
        with ZipFile(BytesIO(content)) as archive:
            if len(archive.infolist()) > 1000 or sum(x.file_size for x in archive.infolist()) > 80 * 1024 * 1024:
                raise ValueError('XLSX 解压数据过大，已拒绝读取')
            if any('vbaproject' in x.filename.casefold() for x in archive.infolist()):
                raise ValueError('不接受包含宏的文件，请另存为无宏 XLSX')
        wb = load_workbook(BytesIO(content), read_only=True, data_only=False, keep_links=False)
        # Some genuine exports incorrectly declare A1:A1 despite dozens of columns.
        # Stream actual XML cells instead of trusting exporter dimensions.
        for sheet in wb:
            sheet.reset_dimensions()
        return wb
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError('无法读取 XLSX 文件，请检查文件格式和完整性') from exc


def _mapping(headers, aliases):
    result = {}
    for key, options in aliases.items():
        matches = [i for i, h in enumerate(headers) if normalize(h) in {normalize(a) for a in [key, *options]}]
        if len(matches) > 1:
            raise ValueError(f'字段 {key} 匹配到多列，请修正重复表头')
        if matches:
            result[key] = matches[0]
    return result


def _find_sheet(wb, aliases, required):
    candidates = []
    for sheet in wb:
        if (sheet.max_row or 0) > 100001 or (sheet.max_column or 0) > 256:
            raise ValueError(f'工作表 {sheet.title} 超过 100000 行或 256 列上限')
        for row_no, cells in enumerate(sheet.iter_rows(max_row=min(sheet.max_row or 20, 20)), 1):
            headers = [c.value for c in cells]
            mapping = _mapping(headers, aliases)
            if all(x in mapping for x in required):
                candidates.append((sheet, row_no, headers, mapping))
                break
    if not candidates:
        raise ValueError('未找到必要表头：' + '、'.join(required))
    preferred = [x for x in candidates if x[0].title == '库存明细']
    if len(candidates) > 1 and not preferred:
        raise ValueError('多个工作表包含库存表头，请保留唯一库存明细表')
    return (preferred or candidates)[0]


def _fixed_inventory_sheet(wb, warnings):
    current = STANDARD['inventory_sheet']
    legacy = STANDARD['legacy_inventory_sheet']
    clearance = STANDARD['optional_clearance_sheet']
    candidates = [name for name in (current, legacy) if name in wb.sheetnames]
    unknown = [name for name in wb.sheetnames if name not in {current, legacy, clearance}]
    if unknown or len(candidates) != 1:
        raise ValueError(f'结构错误：标准库存工作表应为“{current}”（仅兼容旧版“{legacy}”），可选“{clearance}”；实际为 ' + '、'.join(wb.sheetnames))
    sheet = wb[candidates[0]]
    headers = [cell.value for cell in next(sheet.iter_rows(max_row=1), ())]
    expected = STANDARD['headers']
    if headers != expected:
        detail = next((f'第 {i + 1} 列应为 {want!r}，实际为 {(headers[i] if i < len(headers) else None)!r}'
                       for i, want in enumerate(expected) if i >= len(headers) or headers[i] != want), '')
        if len(headers) != len(expected):
            detail = f'应为 {len(expected)} 列，实际 {len(headers)} 列；' + detail
        raise ValueError('结构错误：库存第 1 行必须保持标准的 36 个完整表头和列顺序；' + detail)
    if clearance in wb.sheetnames:
        actual = [cell.value for cell in next(wb[clearance].iter_rows(max_row=1), ())]
        if actual != STANDARD['clearance_headers']:
            raise ValueError(f'结构错误：“{clearance}”第 1 行表头必须为 ' + '、'.join(STANDARD['clearance_headers']))
    if sheet.title == legacy:
        warnings.append('当前文件使用旧版“库存明细”工作表，按标准 36 列显式兼容；新版标准工作表为 sheet1')
    return sheet, 1, headers, _mapping(headers, FIELDS)


def _text(cell, warnings, label, is_code=False):
    value = cell.value if cell is not None else None
    if value is None:
        return ''
    if isinstance(value, str):
        text = value.strip()
        if is_code and text != value:
            warnings.append(f'{label}：编码首尾空格已去除，原始值仍保留')
        return text
    if is_code and isinstance(value, (int, float)) and not isinstance(value, bool):
        if not float(value).is_integer():
            raise ValueError('商品编码为非整数数字，必须以文本保存')
        if abs(value) >= 10 ** 15:
            raise ValueError('数字编码超过 Excel 精度范围，必须修正为原始文本编码')
        fmt = cell.number_format
        if re.fullmatch(r'0+', fmt or ''):
            return str(int(value)).zfill(len(fmt))
        warnings.append(f'{label}：数字编码按整数文本读取，原始前导零无法核实；建议源文件以文本保存')
        return str(int(value))
    if is_code and isinstance(value, (bool, datetime, date)):
        raise ValueError('商品编码格式异常，必须为文本或整数编码')
    return str(_json(value))


def _quantity(value, optional=False, integral=True):
    if value is None or (isinstance(value, str) and not value.strip()):
        if optional:
            return None
        raise ValueError('数量缺失，不得自动填零')
    if isinstance(value, bool):
        raise ValueError('数量不能是布尔值')
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        raise ValueError('应为非负数字，不能包含单位或公式') from None
    if not number.is_finite() or number < 0 or number > 10 ** 12:
        raise ValueError('数量必须在 0 至 1万亿之间')
    if integral and number != number.to_integral_value():
        raise ValueError('数量必须为整数，不能含小数')
    return int(number) if integral else float(number)


def parse_inventory(content: bytes, saved_mapping: dict | None = None) -> dict:
    wb = _open(content)
    errors, warnings, rows = [], [], []
    try:
        try:
            sheet, header_row, headers, cols = _fixed_inventory_sheet(wb, warnings)
        except ValueError as exc:
            actual_sheet = next((name for name in (STANDARD['inventory_sheet'], STANDARD['legacy_inventory_sheet'])
                                 if name in wb.sheetnames), wb.sheetnames[0] if wb.sheetnames else '')
            _error(errors, actual_sheet, 1, '表头', None, str(exc))
            return {'rows': [], 'errors': errors, 'warnings': warnings,
                    'sheets': [{'name': s.title, 'rows': s.max_row, 'columns': s.max_column} for s in wb],
                    'mapping': {}, 'signature': None, 'mapping_reused': False, 'clearance': []}
        signature = sha256(json.dumps([sheet.title, headers], ensure_ascii=False, default=str).encode()).hexdigest()
        saved_used = False
        if saved_mapping and saved_mapping.get('sheet') == sheet.title and saved_mapping.get('signature') == signature:
            saved_cols = {key: headers.index(h) for key, h in saved_mapping.get('fields', {}).items() if h in headers}
            if saved_cols == cols:
                saved_used = True
        for key in ['total', 'locked', 'transit']:
            if key not in cols:
                _error(errors, sheet.title, header_row, key, None, '缺少必要库存字段')
        for key in ['sales7', 'sales15', 'sales30']:
            if key not in cols:
                warnings.append(f'缺少 {key} 销量列，保留缺失状态并停止可靠补货估算')
        duplicate_headers = [str(h) for h, n in Counter(headers).items() if h is not None and n > 1]
        if duplicate_headers:
            raise ValueError('存在重复原始表头：' + '、'.join(duplicate_headers))
        seen = set()
        types = {str(h): Counter() for h in headers if h is not None}
        nulls = {str(h): 0 for h in headers if h is not None}
        for row_no, cells in enumerate(sheet.iter_rows(min_row=header_row + 1), header_row + 1):
            if row_no > 100001 or len(cells) > 256:
                raise ValueError('库存数据超过 100000 行或 256 列安全上限')
            if len(cells) > len(headers) and any(c.value not in (None, '') for c in cells[len(headers):]):
                raise ValueError(f'结构错误：库存第 {row_no} 行包含标准 36 列以外的数据')
            cells = tuple(cells[:len(headers)]) + tuple(EmptyCell() for _ in range(max(0, len(headers) - len(cells))))
            if all(c.value is None or c.value == '' for c in cells):
                continue
            raw = {str(h): _json(cells[i].value) for i, h in enumerate(headers) if h is not None}
            for i, h in enumerate(headers):
                if h is not None:
                    types[str(h)][type(cells[i].value).__name__] += 1
                    nulls[str(h)] += cells[i].value in (None, '')
            record = {'raw': raw, 'source_row': row_no}
            for i, cell in enumerate(cells):
                if cell.data_type == 'f':
                    _error(errors, sheet.title, row_no, str(headers[i]), cell.value, '禁止公式输入；请粘贴为值后重新导入')
            for key in FIELDS:
                cell = cells[cols[key]] if key in cols else None
                value = cell.value if cell is not None else None
                try:
                    if key in ['total', 'available', 'locked', 'transit', 'warning', 'sales7', 'sales15', 'sales30']:
                        record[key] = _quantity(value, optional=key in ['warning', 'sales7', 'sales15', 'sales30'])
                        if record[key] is None and key.startswith('sales'):
                            warnings.append(f'{sheet.title} 第 {row_no} 行 {key} 缺失，不能当作真实零销量')
                    elif key == 'turnover':
                        record[key] = _quantity(value, optional=True, integral=False)
                    else:
                        record[key] = _text(cell, warnings, f'{sheet.title} 第 {row_no} 行 {key}', key == 'sku')
                except ValueError as exc:
                    record[key] = None
                    _error(errors, sheet.title, row_no, key, value, str(exc))
            for key in ['sku', 'warehouse']:
                if not record[key]:
                    _error(errors, sheet.title, row_no, key, record[key], '唯一业务标识不能为空')
            identity = (record.get('sku'), record.get('warehouse'))
            if identity in seen:
                _error(errors, sheet.title, row_no, 'sku+warehouse', identity, '同 SKU 同仓库重复，禁止导入')
            seen.add(identity)
            if all(record.get(k) is not None for k in ['total', 'available', 'locked']):
                if record['total'] != record['available'] + record['locked']:
                    warnings.append(f'{record["sku"]}：总数量与有效库存+锁定库存不一致，请核实源库存口径；有效库存不再扣锁定库存')
            sales = [record[k] for k in ['sales7', 'sales15', 'sales30']]
            if all(v is not None for v in sales) and not sales[0] <= sales[1] <= sales[2]:
                warnings.append(f'{record["sku"]}：7/15/30 天累计销量非递增，请核实统计口径')
            rows.append(record)
        if not rows:
            _error(errors, sheet.title, header_row + 1, '库存明细', None, '库存表没有有效记录')
        if rows and all(r.get('warning') == 0 for r in rows):
            warnings.append('原表预警数量全部为 0；风险按销量和覆盖周期重新计算，不能据此判定安全')
        price_col = next((i for i, h in enumerate(headers) if normalize(h) in ['purchaseprice', '采购价格']), None)
        currency_col = next((i for i, h in enumerate(headers) if normalize(h) in ['currency', '币种']), None)
        if price_col is not None and any(r['raw'].get(str(headers[price_col])) in (None, '', 0, '0') for r in rows):
            warnings.append('存在缺失或为 0 的采购价格，系统不计算采购金额')
        if currency_col is not None and any(not r['raw'].get(str(headers[currency_col])) for r in rows):
            warnings.append('存在空币种，系统不计算或推测采购金额')
        for h in headers:
            if normalize(h) == 'merchantweightunit':
                values = {r['raw'].get(str(h)) for r in rows} - {None, ''}
                if values - {'g', 'kg'}:
                    warnings.append('重量单位异常：' + '、'.join(map(str, values - {'g', 'kg'})))
            if normalize(h) == 'merchantsidelengthunit':
                values = {r['raw'].get(str(h)) for r in rows} - {None, ''}
                if values - {'m', 'cm'}:
                    warnings.append('长度单位异常：' + '、'.join(map(str, values - {'m', 'cm'})))
        skus = sorted({r['sku'] for r in rows if r['sku']})
        clearance = []
        if '清仓款' in wb.sheetnames:
            cs = wb['清仓款']
            tokens = set()
            for row_no, cells in enumerate(cs.iter_rows(min_row=2), 2):
                if row_no > 100001 or len(cells) > 256:
                    raise ValueError('清仓数据超过安全上限')
                if len(cells) > 1 and any(c.value not in (None, '') for c in cells[1:]):
                    raise ValueError(f'结构错误：清仓款第 {row_no} 行包含商品编码列以外的数据')
                cell = cells[0]
                if cell.value in (None, '') or normalize(cell.value) in {'商品编码', 'sku', '型号'}:
                    continue
                if cell.data_type == 'f':
                    _error(errors, cs.title, row_no, '商品编码', cell.value, '清仓编码禁止公式输入')
                    continue
                try:
                    token = _text(cell, warnings, f'清仓款 第 {row_no} 行', True)
                except ValueError as exc:
                    _error(errors, cs.title, row_no, '商品编码', cell.value, str(exc))
                    continue
                if token in tokens:
                    warnings.append(f'清仓编码 {token} 重复，已按同一条匹配规则处理')
                    continue
                tokens.add(token)
                candidates = [s for s in skus if s == token or s.startswith(token + '-')]
                kind = 'exact' if token in skus else ('boundary' if candidates else 'unmatched')
                clearance.append({'token': token, 'candidates': [token] if kind == 'exact' else candidates, 'kind': kind})
            if any(c['kind'] == 'boundary' for c in clearance):
                warnings.append('清仓型号以“型号-”边界生成候选；未经人工确认不自动禁补，请先完成清仓匹配')
            if any(c['kind'] == 'unmatched' for c in clearance):
                warnings.append('清仓表存在未匹配编码，需人工核对完整 SKU')
        else:
            warnings.append('新标准不要求清仓款工作表；本次未提供清仓列表，沿用数据库已有清仓人工规则与已确认映射，不清空')
        sheets = []
        for s in wb:
            metadata = {'name': s.title, 'rows': s.max_row, 'columns': s.max_column}
            if s.title == sheet.title:
                metadata.update({'rows': len(rows) + 1, 'columns': len(headers), 'header_row': header_row, 'data_rows': len(rows), 'headers': headers,
                                 'types': {k: dict(v) for k, v in types.items()}, 'nulls': nulls})
            sheets.append(metadata)
        return {'rows': rows, 'errors': errors, 'warnings': warnings, 'sheets': sheets,
                'mapping': {'sheet': sheet.title, 'header_row': header_row, 'signature': signature,
                            'fields': {k: headers[i] for k, i in cols.items()}},
                'signature': signature, 'mapping_reused': saved_used, 'clearance': clearance}
    finally:
        wb.close()


def _date(value):
    if value is None or value == '':
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    try:
        return date.fromisoformat(str(value).strip()).isoformat()
    except ValueError:
        raise ValueError('日期必须为 YYYY-MM-DD 或 Excel 日期单元格') from None


def parse_transit(content: bytes) -> dict:
    wb = _open(content)
    errors, warnings, records = [], [], []
    try:
        sheet, header_row, headers, cols = _find_sheet(wb, TRANSIT_FIELDS, ['sku', 'warehouse', 'qty'])
        seen = set()
        for row_no, cells in enumerate(sheet.iter_rows(min_row=header_row + 1), header_row + 1):
            if row_no > 100001 or len(cells) > 256:
                raise ValueError('在途数据超过 100000 行或 256 列安全上限')
            cells = tuple(cells) + tuple(EmptyCell() for _ in range(max(0, len(headers) - len(cells))))
            if all(c.value in (None, '') for c in cells):
                continue
            record = {}
            for cell in cells:
                if cell.data_type == 'f':
                    _error(errors, sheet.title, row_no, cell.coordinate, cell.value, '在途明细禁止公式输入')
            for key in TRANSIT_FIELDS:
                cell = cells[cols[key]] if key in cols else None
                value = cell.value if cell is not None else None
                try:
                    if key == 'qty':
                        record[key] = _quantity(value)
                        if record[key] == 0:
                            raise ValueError('在途明细数量必须大于 0')
                    elif key in {'eta', 'purchase_date', 'ship_date', 'actual_date'}:
                        record[key] = _date(value)
                    else:
                        record[key] = _text(cell, warnings, f'在途第 {row_no} 行 {key}', key in {'sku', 'batch'})
                except ValueError as exc:
                    record[key] = None
                    _error(errors, sheet.title, row_no, key, value, str(exc))
            for key in ['sku', 'warehouse']:
                if not record[key]:
                    _error(errors, sheet.title, row_no, key, None, 'SKU 和仓库不能为空')
            record['status'] = record.get('status') or '待补充信息'
            if record['status'] not in ALL_STATUSES:
                _error(errors, sheet.title, row_no, 'status', record['status'], '在途状态不在支持列表')
            relations = {'快照内': 'snapshot', '快照外新增': 'new', '库存快照内': 'snapshot', '新增': 'new'}
            record['relation'] = relations.get(record.get('relation'), record.get('relation')) or 'snapshot'
            if record['relation'] not in {'snapshot', 'new'}:
                _error(errors, sheet.title, row_no, 'relation', record['relation'], '来源关系只允许 snapshot 或 new')
            if 'relation' not in cols:
                warnings.append(f'在途第 {row_no} 行：未提供关联方式，按当前快照组成部分处理，不叠加库存汇总')
            if not record.get('batch') or not record.get('eta'):
                warnings.append(f'在途第 {row_no} 行：待补充批次号或 ETA，不编造缺失信息')
            if record.get('ship_date') and record.get('purchase_date') and record['ship_date'] < record['purchase_date']:
                _error(errors, sheet.title, row_no, 'ship_date', record['ship_date'], '发货日期早于采购日期')
            if record.get('actual_date') and record.get('ship_date') and record['actual_date'] < record['ship_date']:
                _error(errors, sheet.title, row_no, 'actual_date', record['actual_date'], '实际入库日期早于发货日期')
            fingerprint = json.dumps(record, sort_keys=True, ensure_ascii=False)
            if fingerprint in seen:
                _error(errors, sheet.title, row_no, '在途明细', record.get('batch'), '文件内存在完全重复在途行，禁止重复计算')
            seen.add(fingerprint)
            records.append(record)
        if not records:
            _error(errors, sheet.title, header_row + 1, '在途明细', None, '没有在途明细数据')
        return {'rows': records, 'errors': errors, 'warnings': warnings}
    finally:
        wb.close()
