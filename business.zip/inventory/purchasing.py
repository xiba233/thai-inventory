"""Purchase commitments and immutable shipment transfers; no physical stock edits."""
import hashlib
import json
import math
from datetime import date, datetime, timedelta, timezone

ACTIVE_SHIPPING = {'待补充信息', '待发货', '运输中', '清关中', '待入库'}
RELATIONS = {'new', 'snapshot', 'exclude'}


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def business_today():
    return datetime.now(timezone(timedelta(hours=7))).date().isoformat()


def day(value, label, required=False):
    if value in (None, '') and not required:
        return None
    try:
        return date.fromisoformat(str(value)).isoformat()
    except (ValueError, TypeError):
        raise ValueError(label + '必须填写真实日期 YYYY-MM-DD')


def quantity(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value != int(value) or not minimum <= value <= 10**12:
        raise ValueError(label + f'必须为{minimum}至1,000,000,000,000的整数')
    return int(value)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True)


def request_identity(value, payload):
    key = value.get('request_key')
    if not isinstance(key, str) or not 16 <= len(key) <= 128:
        raise ValueError('缺少操作识别码，请重新打开录入窗口')
    return key, hashlib.sha256(encoded(payload).encode('utf-8')).hexdigest()


class PurchasingMixin:
    def _simple_key(self, conn, value):
        sku = value.get('sku')
        if not isinstance(sku, str) or not sku:
            raise ValueError('请选择完整SKU')
        latest = self._latest(conn)
        if not latest:
            raise ValueError('请先导入库存数据')
        products = conn.execute('SELECT warehouse FROM products WHERE sku=? AND last_import=?', (sku, latest['id'])).fetchall()
        warehouse = value.get('warehouse')
        if warehouse:
            if warehouse not in [p['warehouse'] for p in products]:
                raise ValueError('该SKU与仓库不在当前快照中')
        elif len(products) == 1:
            warehouse = products[0]['warehouse']
        else:
            raise ValueError('该SKU不存在于当前快照，或分属多个仓库；请在SKU列表选择具体商品及仓库')
        self._purchase_editable(conn, {'sku': sku})
        return sku, warehouse, latest

    def save_simple_purchase(self, value):
        with self.connect() as conn:
            sku, warehouse, latest = self._simple_key(conn, value)
        # This entry records new, previously unrecorded factory commitments.
        # No completion, ETA, order number or manufacturing facts are invented.
        return self.save_purchase({'sku': sku, 'warehouse': warehouse,
                                  'qty': value.get('qty'), 'purchase_date': value.get('purchase_date'),
                                  'request_key': value.get('request_key')}, allow_same_day=True)

    def record_shipment(self, value):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            sku, warehouse, latest = self._simple_key(conn, value)
            item = {'sku': sku, 'warehouse': warehouse,
                    'qty': quantity(value.get('qty'), '出货数量', 1),
                    'ship_date': day(value.get('ship_date'), '实际发货日期', True)}
            request_key, fingerprint = request_identity(value, item)
            duplicate = conn.execute('SELECT id,request_hash FROM shipment_events WHERE request_key=?', (request_key,)).fetchone()
            if duplicate:
                if duplicate['request_hash'] != fingerprint:
                    raise ValueError('同一次出货操作内容已改变，请重新打开录入入口')
                return {'ok': True, 'id': duplicate['id'], 'duplicate': True}
            if item['ship_date'] > business_today():
                raise ValueError('发货日期须为实际日期，不能填写未来时间')
            orders = []
            for record in conn.execute("SELECT * FROM purchases WHERE sku=? AND warehouse=? AND deleted_at IS NULL AND cancelled=0 AND relation!='exclude' ORDER BY purchase_date,id", (sku, warehouse)):
                order = dict(record)
                remaining = order['qty'] - self._shipped(conn, order['id'])
                if remaining <= 0:
                    continue
                if order['reconcile_state'] != 'confirmed' or order['linked_import'] != latest['id']:
                    raise ValueError('该SKU存在待核对采购，先确认与最新库存快照的关系再录出货')
                if order['purchase_date'] <= item['ship_date']:
                    orders.append((order, remaining))
            available = sum(remaining for order, remaining in orders)
            if item['qty'] > available:
                raise ValueError(f'出货数量超过发货日期前的有效采购未出货余量（{available}件）；请先补录真实采购或核实日期')
            event_id = conn.execute('INSERT INTO shipment_events(sku,warehouse,qty,ship_date,request_key,request_hash,created_at) VALUES(?,?,?,?,?,?,?)',
                                    (sku, warehouse, item['qty'], item['ship_date'], request_key, fingerprint, stamp())).lastrowid
            outstanding, allocations = item['qty'], []
            for order, remaining in orders:
                if outstanding == 0:
                    break
                qty = min(remaining, outstanding)
                child_key = hashlib.sha256(('sku-shipment:' + request_key + ':' + str(order['id'])).encode()).hexdigest()
                result = self._ship_purchase(conn, {'id': order['id'], 'qty': qty, 'ship_date': item['ship_date'],
                                                   'request_key': child_key, 'relation': order['relation']}, automatic=True)
                conn.execute('UPDATE purchase_shipments SET event_id=? WHERE id=?', (event_id, result['id']))
                allocations.append({'purchase_id': order['id'], 'shipment_id': result['id'], 'transit_id': result['transit_id'], 'qty': qty})
                outstanding -= qty
            self._audit(conn, '按SKU自动分配实际出货', {'event_id': event_id, **item, 'allocations': allocations, 'rule': '采购日期升序、相同日期内部编号升序'})
            remaining_total = available - item['qty'] + sum(o['qty'] - self._shipped(conn, o['id']) for o in
                              conn.execute("SELECT * FROM purchases WHERE sku=? AND warehouse=? AND deleted_at IS NULL AND cancelled=0 AND relation!='exclude' AND purchase_date>?", (sku, warehouse, item['ship_date'])))
        return {'ok': True, 'id': event_id, 'allocations': allocations, 'remaining_qty': remaining_total}

    def _purchase(self, conn, value, allow_deleted=False):
        order_id = self._record_id(value.get('id'))
        order = conn.execute('SELECT * FROM purchases WHERE id=?', (order_id,)).fetchone()
        if not order:
            raise ValueError('采购记录不存在')
        if order['deleted_at'] and not allow_deleted:
            raise ValueError('采购记录已删除，请先恢复记录')
        return dict(order)

    def _shipped(self, conn, order_id):
        return conn.execute('SELECT COALESCE(sum(qty),0) FROM purchase_shipments WHERE purchase_id=? AND voided_at IS NULL', (order_id,)).fetchone()[0]

    def _purchase_editable(self, conn, order):
        if conn.execute('SELECT 1 FROM retired_skus WHERE sku=?', (order['sku'],)).fetchone():
            raise ValueError('该商品已清仓完成，请先恢复商品')

    def _validate_purchase_allocation(self, conn, sku, warehouse):
        latest = self._latest(conn)
        if not latest:
            raise ValueError('请先导入库存快照')
        record = conn.execute('SELECT data,last_import FROM products WHERE sku=? AND warehouse=?', (sku, warehouse)).fetchone()
        if record['last_import'] != latest['id']:
            raise ValueError('该商品在最新快照中缺失，请先核实库存')
        source = json.loads(record['data']).get('transit') or 0
        matched = conn.execute("SELECT COALESCE(sum(qty),0) FROM transit WHERE sku=? AND warehouse=? AND relation='snapshot' AND reconcile_state='confirmed' AND linked_import=? AND deleted_at IS NULL AND status NOT IN ('已入库','已取消')", (sku, warehouse, latest['id'])).fetchone()[0]
        for p in conn.execute("SELECT id,qty FROM purchases WHERE sku=? AND warehouse=? AND deleted_at IS NULL AND cancelled=0 AND relation='snapshot' AND reconcile_state='confirmed' AND linked_import=?", (sku, warehouse, latest['id'])):
            matched += p['qty'] - self._shipped(conn, p['id'])
        if matched > source:
            raise ValueError(f'已分配的采购/出货数量{matched}超过Excel在途汇总{source}，本次未保存；请核实快照归属，不能重复计货')

    def save_purchase(self, value, allow_same_day=False):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            previous = self._purchase(conn, value) if value.get('id') is not None else None
            sku, warehouse = self._key(conn, value)
            item = {'sku': sku, 'warehouse': warehouse,
                    'qty': quantity(value.get('qty'), '总采购数量', 1),
                    'completed_qty': quantity(value.get('completed_qty', 0), '累计生产完成数量'),
                    'purchase_date': day(value.get('purchase_date'), '采购日期', True),
                    'eta': day(value.get('eta'), '未出货部分预计入库日期'),
                    'order_number': str(value.get('order_number') or '').strip(),
                    'supplier': str(value.get('supplier') or '').strip(),
                    'note': str(value.get('note') or '').strip(),
                    'relation': value.get('relation', 'new')}
            if item['relation'] not in RELATIONS:
                raise ValueError('请选择未出货部分与当前Excel在途的关系')
            if item['purchase_date'] > business_today():
                raise ValueError('仅登记已实际采购的订单，采购日期不能在未来')
            if item['eta'] and item['eta'] < item['purchase_date']:
                raise ValueError('预计入库日期不能早于采购日期')
            if item['completed_qty'] > item['qty']:
                raise ValueError('累计完成数量不能超过总采购数量')
            key, fingerprint = request_identity(value, item) if not previous else (None, None)
            item['reported_completed_qty'] = item['completed_qty']
            if key:
                duplicate = conn.execute('SELECT id,request_hash FROM purchases WHERE request_key=?', (key,)).fetchone()
                if duplicate:
                    if duplicate['request_hash'] != fingerprint:
                        raise ValueError('相同操作识别码的内容不同，请重新打开录入窗口')
                    return {'ok': True, 'id': duplicate['id'], 'duplicate': True}
            self._purchase_editable(conn, item)
            if previous:
                if previous['cancelled']:
                    raise ValueError('余量已取消，请先恢复采购余量后再编辑')
                history = conn.execute('SELECT * FROM purchase_shipments WHERE purchase_id=?', (previous['id'],)).fetchall()
                if history and (sku, warehouse) != (previous['sku'], previous['warehouse']):
                    raise ValueError('已有出货历史的订单不能更换SKU或仓库')
                shipped = self._shipped(conn, previous['id'])
                if item['completed_qty'] < shipped or item['qty'] < shipped:
                    raise ValueError('累计完成或采购数量不能小于已出货数量')
                if any(s['voided_at'] is None and s['ship_date'] < item['purchase_date'] for s in history):
                    raise ValueError('采购日期不能晚于已经记录的出货日期')
            else:
                shipped = 0
            if item['order_number']:
                duplicate = conn.execute('SELECT id FROM purchases WHERE sku=? AND warehouse=? AND order_number=? AND deleted_at IS NULL AND id!=?', (sku, warehouse, item['order_number'], previous['id'] if previous else -1)).fetchone()
            elif not previous and not allow_same_day:
                duplicate = conn.execute("SELECT id FROM purchases WHERE sku=? AND warehouse=? AND order_number='' AND qty=? AND purchase_date=? AND deleted_at IS NULL AND cancelled=0", (sku, warehouse, item['qty'], item['purchase_date'])).fetchone()
            else:
                duplicate = None
            if duplicate:
                raise ValueError(f'可能重复采购记录#{duplicate["id"]}，请编辑原记录或提供不同的真实采购单号')
            latest = self._latest(conn)
            item.update(linked_import=latest['id'] if latest else None, reconcile_state='confirmed', updated_at=stamp())
            if previous:
                fields = list(item)
                conn.execute('UPDATE purchases SET ' + ','.join(f'{f}=?' for f in fields) + ' WHERE id=?', [item[f] for f in fields] + [previous['id']])
                order_id = previous['id']
            else:
                item.update(cancelled=0, created_at=stamp(), request_key=key, request_hash=fingerprint)
                fields = list(item)
                order_id = conn.execute('INSERT INTO purchases(' + ','.join(fields) + ') VALUES(' + ','.join('?' for _ in fields) + ')', [item[f] for f in fields]).lastrowid
            if item['relation'] == 'snapshot':
                self._validate_purchase_allocation(conn, sku, warehouse)
            self._audit(conn, '保存已采购未出货订单', {'id': order_id, 'previous': previous, 'value': item})
        return {'ok': True, 'id': order_id}

    def ship_purchase(self, value):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            return self._ship_purchase(conn, value)

    def _ship_purchase(self, conn, value, automatic=False):
        order = self._purchase(conn, value)
        qty = quantity(value.get('qty'), '本批出货数量', 1)
        ship_date = day(value.get('ship_date'), '实际出货日期', True)
        item = {'purchase_id': order['id'], 'qty': qty, 'ship_date': ship_date,
                'eta': day(value.get('eta'), '本批预计入库日期'),
                'batch': str(value.get('batch') or '').strip(), 'note': str(value.get('note') or '').strip(),
                'relation': value.get('relation', order['relation'])}
        key, fingerprint = request_identity(value, item)
        duplicate = conn.execute('SELECT id,transit_id,request_hash FROM purchase_shipments WHERE request_key=?', (key,)).fetchone()
        if duplicate:
            if duplicate['request_hash'] != fingerprint:
                raise ValueError('同一出货操作的内容不同，请重新打开窗口')
            return {'ok': True, 'id': duplicate['id'], 'transit_id': duplicate['transit_id'], 'duplicate': True}
        self._purchase_editable(conn, order)
        if order['cancelled']:
            raise ValueError('采购未出货余量已取消，不能继续出货')
        latest = self._latest(conn)
        if order['reconcile_state'] != 'confirmed' or not latest or order['linked_import'] != latest['id'] or order['relation'] == 'exclude':
            raise ValueError('请先核对采购未出货部分与最新快照的关系')
        shipped = self._shipped(conn, order['id'])
        if automatic:
            if qty > order['qty'] - shipped:
                raise ValueError('本批出货数量超过采购未出货余量')
            order['completed_qty'] = max(order['reported_completed_qty'], shipped + qty)
            conn.execute('UPDATE purchases SET completed_qty=? WHERE id=?', (order['completed_qty'], order['id']))
        if qty > order['completed_qty'] - shipped:
            raise ValueError('本批数量超过已完成且尚未出货数量，请先维护真实累计生产完成数量')
        if ship_date < order['purchase_date'] or ship_date > business_today():
            raise ValueError('实际出货日期须在采购日期与今天之间，不能填写未来出货')
        if item['eta'] and item['eta'] < ship_date:
            raise ValueError('本批预计入库日期不能早于出货日期')
        if item['relation'] not in {'snapshot', 'new'}:
            raise ValueError('请选择本批已包含快照或属于快照外新增')
        if order['relation'] == 'snapshot' and item['relation'] != 'snapshot':
            raise ValueError('本订单已包含Excel汇总，出货部分也须作为其组成；若归属有误请先核对订单')
        # Internal shipment identity is distinct from an actual supplier/transport number.
        transit_id = self._write_transit(conn, {'sku': order['sku'], 'warehouse': order['warehouse'],
                       'qty': qty, 'batch': item['batch'], 'eta': item['eta'], 'status': '运输中',
                       'purchase_date': order['purchase_date'], 'ship_date': ship_date,
                       'relation': item['relation'], 'note': item['note']}, purchase_transfer=True)
        shipping = {'purchase_id': order['id'], 'transit_id': transit_id, 'qty': qty, 'ship_date': ship_date,
                    'request_key': key, 'request_hash': fingerprint, 'created_at': stamp()}
        fields = list(shipping)
        shipment_id = conn.execute('INSERT INTO purchase_shipments(' + ','.join(fields) + ') VALUES(' + ','.join('?' for _ in fields) + ')', [shipping[f] for f in fields]).lastrowid
        conn.execute('UPDATE purchases SET updated_at=? WHERE id=?', (stamp(), order['id']))
        if item['relation'] == 'snapshot':
            self._validate_purchase_allocation(conn, order['sku'], order['warehouse'])
        self._audit(conn, '采购分批出货并转入在途', {'purchase_id': order['id'], 'shipment_id': shipment_id, 'transit_id': transit_id, **item})
        return {'ok': True, 'id': shipment_id, 'transit_id': transit_id, 'remaining_qty': order['qty'] - shipped - qty}


    def delete_purchase(self, value):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            order = self._purchase(conn, value, allow_deleted=True)
            if order['deleted_at']:
                return {'ok': True, 'id': order['id'], 'duplicate': True}
            shipped = self._shipped(conn, order['id'])
            # Confirmation is for this exact order, never every order of a SKU.
            for field, current in [('expected_qty', order['qty']), ('expected_shipped_qty', shipped)]:
                if field in value and value[field] != current:
                    raise ValueError('采购数量或出货记录已改变，请关闭窗口后重新核对此条记录')
            timestamp = stamp()
            conn.execute('UPDATE purchases SET deleted_at=?,updated_at=? WHERE id=?', (timestamp, timestamp, order['id']))
            self._audit(conn, '删除采购记录', {'id': order['id'], 'sku': order['sku'], 'warehouse': order['warehouse'],
                       'previous': order, 'remaining_removed': 0 if order['cancelled'] or order['relation']=='exclude' else order['qty']-shipped,
                       'shipped_preserved': shipped})
        return {'ok': True, 'id': order['id']}

    def restore_purchase(self, value):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            order = self._purchase(conn, value, allow_deleted=True)
            if not order['deleted_at']:
                return {'ok': True, 'id': order['id'], 'duplicate': True}
            timestamp = stamp()
            latest = self._latest(conn)
            # A snapshot imported while archived cannot be presumed reconciled.
            pending = not latest or order['linked_import'] != latest['id']
            conn.execute('UPDATE purchases SET deleted_at=NULL,updated_at=?,reconcile_state=? WHERE id=?',
                         (timestamp, 'pending' if pending else order['reconcile_state'], order['id']))
            if not pending and not order['cancelled'] and order['relation']=='snapshot' and order['reconcile_state']=='confirmed':
                self._validate_purchase_allocation(conn, order['sku'], order['warehouse'])
            self._audit(conn, '恢复已删除采购记录', {'id': order['id'], 'sku': order['sku'], 'warehouse': order['warehouse'],
                       'previous': order, 'pending': pending})
        return {'ok': True, 'id': order['id'], 'pending': pending}

    def cancel_purchase(self, value):
        cancelled = value.get('cancelled')
        if not isinstance(cancelled, bool):
            raise ValueError('请选择取消或恢复未出货余量')
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            order = self._purchase(conn, value)
            self._purchase_editable(conn, order)
            conn.execute('UPDATE purchases SET cancelled=?,updated_at=? WHERE id=?', (int(cancelled), stamp(), order['id']))
            if not cancelled and order['relation'] == 'snapshot' and order['reconcile_state'] == 'confirmed':
                self._validate_purchase_allocation(conn, order['sku'], order['warehouse'])
            self._audit(conn, '取消采购未出货余量' if cancelled else '恢复采购未出货余量', {'id': order['id'], 'shipped_unchanged': self._shipped(conn, order['id'])})
        return {'ok': True}

    def reconcile_purchase(self, value):
        relation = value.get('relation')
        if relation not in RELATIONS:
            raise ValueError('请选择未出货余量的快照归属')
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            order = self._purchase(conn, value)
            self._purchase_editable(conn, order)
            latest = self._latest(conn)
            conn.execute("UPDATE purchases SET relation=?,linked_import=?,reconcile_state='confirmed',updated_at=? WHERE id=?", (relation, latest['id'] if latest else None, stamp(), order['id']))
            if relation == 'snapshot' and not order['cancelled']:
                self._validate_purchase_allocation(conn, order['sku'], order['warehouse'])
            self._audit(conn, '采购未出货余量快照核对', value)
        return {'ok': True}

    def undo_purchase_shipment(self, value):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            return self._undo_purchase_shipment(conn, value)

    def _undo_purchase_shipment(self, conn, value):
        shipment_id = self._record_id(value.get('id'))
        s = conn.execute('SELECT s.*,t.status,t.reconcile_state,t.linked_import,t.relation FROM purchase_shipments s JOIN transit t ON t.id=s.transit_id WHERE s.id=?', (shipment_id,)).fetchone()
        if not s:
            raise ValueError('该出货记录不存在')
        if s['voided_at']:
            if value.get('retry_safe') is True:
                return {'ok': True, 'duplicate': True, 'shipment_id': shipment_id, 'purchase_id': s['purchase_id']}
            raise ValueError('该出货记录已撤销')
        latest = self._latest(conn)
        order = self._purchase(conn, {'id': s['purchase_id']}, allow_deleted=True)
        self._purchase_editable(conn, order)
        if s['status'] == '已入库':
            raise ValueError('已入库批次不能撤销出货；请核对仓库快照和实际业务')
        if not latest or s['linked_import'] != latest['id'] or s['reconcile_state'] != 'confirmed' or s['relation'] != 'new':
            raise ValueError('仅可撤销已确认属于当前快照外新增的误录出货；快照内或待核对记录须先核实来源')
        timestamp = stamp()
        conn.execute('UPDATE purchase_shipments SET voided_at=? WHERE id=?', (timestamp, shipment_id))
        conn.execute('UPDATE transit SET deleted_at=?,updated_at=? WHERE id=?', (timestamp, timestamp, s['transit_id']))
        conn.execute('UPDATE purchases SET completed_qty=?,updated_at=? WHERE id=?', (max(order['reported_completed_qty'], self._shipped(conn, order['id'])), timestamp, order['id']))
        if order['relation'] == 'snapshot' and not order['cancelled'] and not order['deleted_at']:
            self._validate_purchase_allocation(conn, order['sku'], order['warehouse'])
        self._audit(conn, '撤销误录分批出货并恢复未出货余量', {'shipment_id': shipment_id, 'purchase_id': s['purchase_id'], 'transit_id': s['transit_id'], 'qty': s['qty']})
        return {'ok': True, 'shipment_id': shipment_id, 'purchase_id': s['purchase_id'], 'qty': s['qty']}

    def purchase_state(self, conn, products, transits, current_id, retired_skus):
        product_map = {(p['sku'], p['warehouse']): p for p in products}
        shipments = []
        for saved in conn.execute('SELECT s.*,t.sku,t.warehouse,t.status,t.eta,t.batch,t.note,t.actual_date,t.relation,t.reconcile_state,t.linked_import,t.deleted_at,p.purchase_date,p.order_number,p.deleted_at AS purchase_deleted_at FROM purchase_shipments s JOIN transit t ON t.id=s.transit_id JOIN purchases p ON p.id=s.purchase_id ORDER BY s.id DESC'):
            item = dict(saved)
            item['name'] = json.loads(product_map[(item['sku'], item['warehouse'])]['data']).get('name', '')
            shipments.append(item)
        for transit in transits:
            link = next((s for s in shipments if s['transit_id'] == transit['id'] and not s['voided_at']), None)
            if link:
                transit.update(purchase_id=link['purchase_id'], shipment_id=link['id'])
        orders = []
        for saved in conn.execute('SELECT * FROM purchases ORDER BY id DESC'):
            p = dict(saved)
            record = product_map[(p['sku'], p['warehouse'])]
            p['name'] = json.loads(record['data']).get('name', '')
            p['shipments'] = [s for s in shipments if s['purchase_id'] == p['id']]
            active = [s for s in p['shipments'] if not s['voided_at']]
            p['shipped_qty'] = sum(s['qty'] for s in active)
            p['remaining_qty'] = p['qty'] - p['shipped_qty']
            p['unfinished_qty'] = p['qty'] - p['completed_qty']
            p['ready_qty'] = p['completed_qty'] - p['shipped_qty']
            p['unshipped_qty'] = 0 if p['cancelled'] or p['deleted_at'] else p['remaining_qty']
            p['cancelled_qty'] = p['remaining_qty'] if p['cancelled'] else 0
            p['received_qty'] = sum(s['qty'] for s in active if s['status'] == '已入库')
            p['excluded'] = p['sku'] in retired_skus or record['last_import'] != current_id
            p['status'] = ('已删除' if p['deleted_at'] else '余量已取消' if p['cancelled'] else '已全部出货' if not p['remaining_qty'] else '部分已出货' if p['shipped_qty'] else '已完成待出货' if p['completed_qty'] == p['qty'] else '生产中' if p['completed_qty'] else '待生产')
            orders.append(p)
        return orders, shipments
