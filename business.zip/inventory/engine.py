"""Explainable stock coverage/reorder calculation, independent of UI and storage.

Sales windows overlap; the weighted rate estimates recent speed, not daily sales.
Only reconciled arrivals supplied by the service may be passed to this module.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from fractions import Fraction
import math


DEFAULTS = {
    'weights': [.5, .3, .2], 'factory_days': 14, 'domestic_days': 0, 'crossborder_days': 14,
    'safety_days': 7, 'emergency_days': 3, 'attention_days': 14,
    'stale_days': 7, 'moq': 1, 'pack': 1, 'assumed': True,
}
ACTIVE_STATUSES = {'待发货', '运输中', '清关中', '待入库'}


def normalize_params(p):
    """Migrate persisted legacy keys; explicit new values always take precedence."""
    if not isinstance(p, dict):
        raise ValueError('补货参数必须为配置对象')
    migrated = dict(p)
    legacy = 'purchase_days' in migrated or 'transport_days' in migrated
    if 'purchase_days' in migrated:
        migrated.setdefault('factory_days', migrated.pop('purchase_days'))
    if 'transport_days' in migrated:
        migrated.setdefault('crossborder_days', migrated.pop('transport_days'))
    if legacy:
        migrated.setdefault('domestic_days', 0)
    return migrated


def validate_params(p):
    if not isinstance(p, dict):
        raise ValueError('补货参数必须为配置对象')
    unknown = set(p) - set(DEFAULTS)
    if unknown:
        raise ValueError('不支持的参数：' + '、'.join(sorted(unknown)))
    merged = {**DEFAULTS, **p}
    weights = merged['weights']
    if not isinstance(weights, (list, tuple)) or len(weights) != 3:
        raise ValueError('需要提供 7/15/30 天三个预测权重')
    if any(isinstance(w, bool) or not isinstance(w, (int, float)) or not math.isfinite(w) or not 0 <= w <= 1 for w in weights):
        raise ValueError('预测权重必须为 0 至 1 的有限数字')
    if not math.isclose(sum(weights), 1, rel_tol=0, abs_tol=1e-9):
        raise ValueError('三个预测权重之和必须为 100%')
    for key in ['factory_days', 'domestic_days', 'crossborder_days', 'safety_days', 'emergency_days', 'attention_days', 'stale_days', 'moq', 'pack']:
        value = merged[key]
        minimum = 1 if key in {'moq', 'pack'} else 0
        maximum = 10 ** 9 if key in {'moq', 'pack'} else 3650
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value != int(value) or not minimum <= value <= maximum:
            raise ValueError(f'{key} 必须为 {minimum} 至 {maximum} 的整数')
    if not isinstance(merged['assumed'], bool):
        raise ValueError('暂定假设标记必须为 true 或 false')
    merged['weights'] = list(weights)
    return merged


def _as_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return date.fromisoformat(value)
        except ValueError:
            return None
    return None


def _ceil(fraction):
    return -(-fraction.numerator // fraction.denominator)


def calculate(row, params=None, arrivals=None, clearance=False, today=None, purchase_arrivals=None):
    params = validate_params(params or {})
    # Business clock uses Bangkok, while storage timestamps remain UTC.
    now = _as_date(today) if today is not None else datetime.now(timezone(timedelta(hours=7))).date()
    if now is None:
        raise ValueError('计算日期必须为 YYYY-MM-DD')
    result = dict(row)
    result.update({'params': params, 'clearance': bool(clearance), 'daily7': None, 'daily15': None,
                   'daily30': None, 'daily': None, 'cover': None, 'target': None,
                   'lead_days': int(params['factory_days'] + params['domestic_days'] + params['crossborder_days']),
                   'target_period': int(params['factory_days'] + params['domestic_days'] + params['crossborder_days'] + params['safety_days']),
                   'reorder_in_days': None, 'reorder_by': None,
                   'timely_transit': 0, 'timely_purchase': 0, 'procurement_credit': 0, 'arrival_gap': None, 'base_qty': None, 'suggestion': 0 if clearance else None,
                   'risk': '数据不足', 'priority': 4, 'reason': '', 'trend': '', 'action': '',
                   'explanation': '', 'unknown_transit': 0, 'transit_total': row.get('transit_total', row.get('transit', 0)) or 0,
                   'projected_shortage_days': None, 'data_warnings': [], 'is_oos': False})
    warnings = result['data_warnings']
    snapshot = _as_date(row.get('snapshot_date'))
    if snapshot is None:
        warnings.append('快照日期来源未确认：以下按导入库存估算，不能视为实时库存')
    elif snapshot > now:
        warnings.append('快照日期在未来，请核实；以下结果仅供待核实分析')
    elif (now - snapshot).days > params['stale_days']:
        warnings.append(f'库存快照已过去 {(now - snapshot).days} 天，超过 {params["stale_days"]} 天时效阈值；请导入最新库存')
    if params['assumed']:
        warnings.append('工厂/国内段/跨境段/安全周期是可配置暂定假设，请按实际供应链核实' +
                        ('；国内段默认 0 天为待核实假设' if params['domestic_days'] == 0 else ''))
    base_intro = '利用重叠的 7/15/30 天销售窗口估计近期销售速度，不代表准确逐日预测。'
    if row.get('missing'):
        result.update(reason='最新导入未包含此 SKU+仓库，保留上一快照待核实，不计入当前运营汇总',
                      action='核实缺失记录或重新导入完整库存文件', explanation=base_intro + '最新快照缺失，暂停补货估算。')
        return result
    sales = [row.get('sales7'), row.get('sales15'), row.get('sales30')]
    for i, days in enumerate([7, 15, 30]):
        if isinstance(sales[i], (int, float)) and not isinstance(sales[i], bool) and math.isfinite(sales[i]) and sales[i] >= 0:
            result[f'daily{days}'] = sales[i] / days
        else:
            sales[i] = None
    available = row.get('available')
    recent_sales = any(v is not None and v > 0 for v in sales)
    if available == 0 and recent_sales:
        result.update(risk='P0', priority=0, is_oos=True)
    if available is None or isinstance(available, bool) or not isinstance(available, (int, float)) or not math.isfinite(available) or available < 0 or any(v is None for v in sales):
        result.update(reason=('当前已缺货；' if result['is_oos'] else '') + '库存或销量缺失/异常，缺失销量不能当作 0，无法可靠计算补货',
                      action='补全库存和 7/15/30 天销量；' + ('优先催货、加急或调拨' if result['is_oos'] else '核实源文件'),
                      explanation=base_intro + '原始数据不足，预测日均销量、覆盖天数和补货目标不生成普通数值。')
        if clearance:
            result['explanation'] += '已确认清仓，常规补货建议为 0。'
        return result
    # Rational arithmetic prevents ceil from adding an accidental unit due to float error.
    weighted = sum(Fraction(str(s)) / days * Fraction(str(weight)) for s, days, weight in zip(sales, [7, 15, 30], params['weights']))
    daily = float(weighted)
    result['daily'] = daily
    rate7, rate30 = result['daily7'], result['daily30']
    if rate30 == 0 and rate7 > 0:
        result['trend'] = '近期开始出现销量，请核实累计销量口径'
    elif rate30 > 0:
        ratio = rate7 / rate30
        if ratio >= 1.5:
            result['trend'] = f'近 7 天日均销量为 30 天的 {ratio:.2f} 倍，近期加速；窗口重叠，仅作趋势提示'
        elif ratio <= .5:
            result['trend'] = f'近 7 天日均销量为 30 天的 {ratio:.2f} 倍，近期减速；窗口重叠，仅作趋势提示'
    transit_total = result['transit_total']
    if not isinstance(transit_total, (int, float)) or not math.isfinite(transit_total) or transit_total < 0:
        transit_total = 0
        result['transit_total'] = 0
        warnings.append('在途汇总异常，不抵扣补货量')
    lead = result['lead_days']
    target_period = result['target_period']
    confirmed = []
    overdue_qty = 0
    purchase_transit_timely = 0
    for arrival in arrivals or []:
        qty = arrival.get('qty')
        eta = _as_date(arrival.get('eta'))
        if arrival.get('status') not in ACTIVE_STATUSES or not isinstance(qty, (int, float)) or isinstance(qty, bool) or not math.isfinite(qty) or qty <= 0 or eta is None:
            continue
        distance = (eta - now).days
        if distance < 0:
            overdue_qty += qty
            continue
        confirmed.append((distance, qty))
        if arrival.get('purchase_id') and distance <= target_period:
            purchase_transit_timely += qty
    confirmed.sort()
    if sum(q for _, q in confirmed) + overdue_qty > transit_total:
        warnings.append('在途明细超过当前在途汇总，存在重复或差异；停止所有明细抵扣并等待核对')
        confirmed = []
        purchase_transit_timely = 0
    known_qty = sum(q for _, q in confirmed)
    result['unknown_transit'] = max(0, transit_total - known_qty)
    if overdue_qty:
        warnings.append(f'{overdue_qty:g} 件在途 ETA 已过期且未入库，不抵扣补货量，请更新到货进度')
    if result['unknown_transit']:
        warnings.append(f'{result["unknown_transit"]:g} 件在途未确认有效到货时间/状态或待核对，不作为按期到货抵扣；关联已确认采购另用于避免重复下单')
    timely = sum(q for day, q in confirmed if day <= target_period)
    result['timely_transit'] = timely
    purchase_known = []
    for arrival in purchase_arrivals or []:
        qty, eta = arrival.get('qty'), _as_date(arrival.get('eta'))
        if isinstance(qty, bool) or not isinstance(qty, (int, float)) or not math.isfinite(qty) or qty <= 0 or eta is None or eta < now:
            continue
        purchase_known.append(((eta - now).days, qty))
    unshipped = row.get('procurement_unshipped', 0)
    reserve = row.get('procurement_reserve', 0)
    if any(isinstance(q, bool) or not isinstance(q, (int, float)) or not math.isfinite(q) or q < 0 for q in (unshipped, reserve)):
        raise ValueError('已采购数量必须为有效非负数')
    if sum(q for _, q in purchase_known) > unshipped:
        purchase_known = []
        warnings.append('未出货到货明细超过已采购余量，暂停其预计到货抵扣')
    timely_purchase = sum(q for d, q in purchase_known if d <= target_period)
    result['timely_purchase'] = timely_purchase
    reserve_credit = max(0, reserve - purchase_transit_timely - timely_purchase)
    result['procurement_credit'] = reserve_credit
    if reserve > 0:
        warnings.append(f'已确认采购尚未入库共{reserve:g}件用于避免重复采购；未确认或超期到货的部分不能消除缺货风险')
    confirmed.extend(purchase_known)
    confirmed.sort()
    if weighted == 0:
        zero_reason = ('选用权重后的预测日均销量为 0，部分窗口仍有销量；请核实权重和近期需求' if recent_sales else
                       '三个销售窗口均为真实 0；没有可估计销售速度，不能可靠判断未来缺货风险')
        result.update(target=0, base_qty=0, suggestion=0,
                      risk='P0' if result['is_oos'] else '数据不足', priority=0 if result['is_oos'] else 4,
                      reason=('当前可售库存为 0 且近期存在销量，已经缺货；' if result['is_oos'] else '') + zero_reason,
                      action=('优先核实需求、催货、加急或调拨；' if result['is_oos'] else '检查滞销/新品状态；') + '选用预测速度为 0，不生成常规补货量',
                      explanation=base_intro + '日均销量=0；覆盖天数不适用（不显示虚构天数或无穷值）；目标库存=0，建议补货=0。')
        if clearance:
            result['explanation'] += '已确认清仓，常规补货禁补。'
        return result
    cover = available / daily
    result['cover'] = cover
    if not clearance:
        # Anchor to the inventory observation date, never to product creation time.
        cover_fraction = Fraction(str(available)) / weighted
        result['reorder_in_days'] = max(0, math.floor(cover_fraction - lead - params['safety_days']))
        if snapshot is not None and snapshot <= now and (now - snapshot).days <= params['stale_days']:
            result['reorder_by'] = (snapshot + timedelta(days=result['reorder_in_days'])).isoformat()
    target = _ceil(weighted * target_period)
    arrival_gap = max(0, target - available - timely - timely_purchase)
    result['arrival_gap'] = int(math.ceil(arrival_gap))
    base = max(0, arrival_gap - reserve_credit)
    # Input quantity contract is integral; preserve integer representation in exports.
    base = int(math.ceil(base))
    suggestion = int(math.ceil(max(base, params['moq']) / params['pack']) * params['pack']) if base else 0
    result.update(target=target, base_qty=base, suggestion=0 if clearance else suggestion)
    # Simulate confirmed arrivals chronologically. A late arrival cannot erase a prior gap.
    balance, previous_day, shortage = available, 0, None
    for day, qty in confirmed:
        if day > lead:
            break
        consumption = daily * (day - previous_day)
        if balance + 1e-9 < consumption:
            shortage = previous_day + balance / daily
            break
        balance = balance - consumption + qty
        previous_day = day
    if shortage is None:
        shortage = previous_day + balance / daily
    result['projected_shortage_days'] = shortage
    if result['is_oos']:
        risk, priority, reason = 'P0', 0, '当前可售库存为 0 且近期存在销量，已经缺货；在途不能当作当前可售库存'
    elif shortage <= params['emergency_days']:
        risk, priority, reason = 'P0', 0, f'按可确认到货顺序推算约 {shortage:.2f} 天后出现缺口，处于极紧急阈值'
    elif shortage < lead:
        risk, priority, reason = 'P1', 1, f'预计约 {shortage:.2f} 天后出现缺口，当前可售库存及按期在途不足以覆盖 {lead} 天补货提前期'
    elif shortage <= target_period + params['attention_days']:
        risk, priority, reason = 'P2', 2, f'可确认在途考虑后预计约 {shortage:.2f} 天后耗尽，接近 {target_period} 天目标周期及关注阈值'
    else:
        risk, priority, reason = 'P3', 3, f'按当前销售速度与已确认到货，预计可覆盖约 {shortage:.2f} 天，超过风险阈值'
    if result['unknown_transit']:
        reason += '；虽然存在在途，但部分预计到货时间/状态未确认，不能据此消除风险'
    if reserve:
        reason += f'；另有已采购未入库{reserve:g}件，减少新采购需求，出货与到货进度仍需确认'
    if clearance:
        reason += '；已确认清仓，正常采购禁补，风险仍保留'
    action = '按建议量制定常规采购计划' if suggestion else '持续观察库存与销量'
    if risk in {'P0', 'P1'}:
        action = '优先催货、加急或调拨；普通补货可能无法覆盖到货前缺口'
    if clearance:
        action = '清仓禁补；' + ('评估是否允许调拨或人工解除清仓标记' if risk in {'P0', 'P1'} else '跟踪清仓销量和剩余库存')
    if result['unknown_transit']:
        action += '；确认在途 ETA 和快照关联'
    if reserve and risk in {'P0', 'P1'} and not clearance:
        action += '；优先催现有采购生产/分批出货，不因未确认到货而重复下单'
    result.update(risk=risk, priority=priority, reason=reason, action=action)
    weights_text = '/'.join(f'{float(w) * 100:g}%' for w in params['weights'])
    result['explanation'] = (
        base_intro + f'日均=({sales[0]}/7×{params["weights"][0]})+({sales[1]}/15×{params["weights"][1]})+({sales[2]}/30×{params["weights"][2]})={daily:.6f} 件/天；'
        f'权重 {weights_text} 为初始可配置模型；可售库存={available:g}（Effective Stock，不再扣锁定库存）；'
        f'覆盖天数={available:g}/{daily:.6f}={cover:.2f}；总提前期=工厂 {params["factory_days"]} +国内段 {params["domestic_days"]} +跨境段 {params["crossborder_days"]}={lead} 天；目标周期=总提前期 {lead} +安全 {params["safety_days"]}={target_period} 天；'
        f'目标库存=向上取整({daily:.6f}×{target_period})={target}；'
        f'有效在途抵扣={timely:g}（仅已核对、状态明确且 ETA 不晚于目标周期，过期 ETA 不计）；'
        f'到货口径缺口=max(0,{target}-{available:g}-{timely:g}-{timely_purchase:g})={result["arrival_gap"]}；'
        f'已采购额外抵扣={reserve:g}-关联采购按期在途{purchase_transit_timely:g}-按期未出货{timely_purchase:g}={reserve_credit:g}（避免同批重复抵扣）；'
        f'新增采购基础需求=max(0,{result["arrival_gap"]}-{reserve_credit:g})={base}；'
        f'MOQ={params["moq"]}，整箱倍数={params["pack"]}，正需求先满足 MOQ 再向上取整箱；建议={result["suggestion"]}。'
    )
    if clearance:
        result['explanation'] += '清仓规则覆盖常规补货量，最终为 0。'
    else:
        result['explanation'] += f'建议补货间隔=max(0,向下取整(覆盖天数 {cover:.2f}-提前期 {lead}-安全 {params["safety_days"]}))={result["reorder_in_days"]} 天（以库存快照时点为基准，未用在途延长该间隔）。'
        if result['reorder_by']:
            result['explanation'] += f'参考下单日期=库存快照日期 {snapshot.isoformat()}+{result["reorder_in_days"]} 天={result["reorder_by"]}；请结合最新库存与在途确认执行。'
        else:
            result['explanation'] += '库存快照日期未知、过期或在未来，不提供确定下单日期；请更新/确认快照。'
    if row.get('procurement_blocked') and not clearance:
        result['suggestion'] = None
        result['reason'] += '；采购/关联出货快照归属待核对，暂停新增采购建议'
        result['action'] += '；先核对采购和在途与当前快照的关系'
        result['explanation'] += '采购或关联出货归属待核对，最终新增采购建议暂不生成普通数量。'
    if warnings:
        result['explanation'] += '注意：' + '；'.join(warnings) + '。'
    return result
